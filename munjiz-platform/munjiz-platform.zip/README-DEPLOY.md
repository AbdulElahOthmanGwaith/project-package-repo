# 🚀 دليل النشر على الإنترنت

## الخيار الأول: Netlify (الأسهل!) ⭐

### إنشاء حساب Netlify

1. **افتح هذا الرابط:**
   👉 https://app.netlify.com/signup

2. **اختر طريقة التسجيل:**
   - ✅ **Sign up with GitHub** (الأسهل)
   - أو Email التقليدي

3. **إذا اخترت GitHub:**
   - سجّل الدخول بحساب GitHub
   - وافق على الأذونات

4. **اكتمل التسجيل!**

### رفع الموقع

```
1. بعد تسجيل الدخول، سترى:
   "Add new site" ← انقر هنا

2. اختر:
   "Deploy manually" ← اسحب الملف هنا

3. اسحب ملف: munjiz-platform.zip

4. Netlify سيستخرج الملفات تلقائياً!

5. تغيير اسم الموقع:
   - Site settings
   - Change site name
   - اكتب: munjiz-platform
   - Save

✅ رابط موقعك:
https://munjiz-platform.netlify.app
```

---

## الخيار الثاني: GitHub Pages

### إنشاء حساب GitHub

1. **افتح هذا الرابط:**
   👉 https://github.com/signup

2. **خطوات التسجيل:**

   ```
   الخطوة 1: Enter your email
   ───────────────────────────
   اكتب بريدك الإلكتروني
   انقر: Continue
   
   الخطوة 2: Create a password
   ───────────────────────────
   اكتب كلمة مرور قوية (10 أحرف على الأقل)
   انقر: Continue
   
   الخطوة 3: Enter a username
   ──────────────────────────
   اختر اسم مستخدم فريد (مثل: ahmed2024)
   انقر: Continue
   
   الخطوة 4: Verify your email
   ───────────────────────────
   سيُرسل لك بريد للتحقق
   افتح البريد وانقر على رابط التحقق
   
   الخطوة 5: Human verification
   ────────────────────────────
   أكمل الـ puzzle البسيط
   انقر: Create account
   ```

### رفع الملفات

```
بعد إنشاء الحساب:

1. أنشئ مستودع جديد:
   https://github.com/new
   - Repository name: munjiz-platform
   - Public: ✅ اخترها
   - لا تختار Initialize with README
   - انقر: Create repository

2. بعد إنشاء المستودع:
   https://github.com/USERNAME/munjiz-platform
   
   سترى:
   "or drag and drop files to upload"
   
   ⬇️ اسحب ملف munjiz-platform.zip هنا

3. بعد رفع الملف:
   - انقر على الملف مرتين
   - right click على الملف
   - Extract here (استخراج هنا)
   
4. الآن يجب أن يكون المحتوى خارج المجلد:
   ✅ index.html
   ✅ css/style.css
   ✅ js/main.js
   
5. حدّد كل الملفات ← Add files ← Commit changes

6. تفعيل Pages:
   Settings → Pages
   Source: main
   Save
   
✅ موقعك سيكون على:
https://USERNAME.github.io/munjiz-platform/
```

---

## 🎯 أي خيار تختار؟

| المعيار | Netlify | GitHub Pages |
|---------|---------|--------------|
| **الصعوبة** | ⭐ سهل جداً | ⭐⭐ سهل |
| **السرعة** | فوري | دقيقة واحدة |
| **رابط جميل** | ✅ | ✅ |
| **مجاناً** | ✅ | ✅ |
| **الـ SEO** | ✅ | ✅ |

**⭐ توصيتي: Netlify** - أسهل وأسرع!

---

## 📋 خطوات Netlify المختصرة

```
1. افتح: https://app.netlify.com/signup
2. سجّل بـ GitHub (أو Email)
3. انقر: Add new site
4. اسحب الملف
5. غيّر اسم الموقع إلى: munjiz-platform
6. 🎉 جاهز!
```

---

## 🆘 إذا واجهت مشكلة

### مشكلة: لا أستطيع رفع الملف
```
✅ الحل: فك ضغط الملف أولاً على جهازك
       ثم ارفع الملفات المنفردة (index.html, css/, js/)
```

### مشكلة: الموقع لا يظهر
```
✅ الحل: انتظر 2-3 دقائق بعد الرفع
       امسح ذاكرة المتصفح (Ctrl+F5)
```

### مشكلة: الخطوط لا تظهر
```
✅ الحل: هذا طبيعي في بيئة Sandbox
       على الإنترنت ستظهر الخطوط بشكل صحيح
```

### مشكلة: GitHub Pages لا تعمل
```
✅ الحل:
1. تأكد أن الملفات في root المستودع
2. اذهب Settings → Pages
3. تأكد اختيار: main branch, /(root)
4. انتظر 2-5 دقائق
```

---

## 📞 المساعدة

إذا واجهتك مشكلة:
1. خذ screenshot للمشكلة
2. اكتب رسالة واضحة بالمشكلة
3. سأقوم بمساعدتك!

---

**✅ ملف جاهز للنشر!**
موقعك سيكون متاحاً على الإنترنت خلال دقائق!

---

*تم إنشاء هذا الدليل لمنصة مُنجز*
*جميع الحقوق محفوظة © 2025*
