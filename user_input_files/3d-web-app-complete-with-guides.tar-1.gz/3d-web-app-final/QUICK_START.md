# دليل البدء السريع - تطبيق الويب ثلاثي الأبعاد المتقدم

## 🚀 البدء السريع (5 دقائق)

### الطريقة الأولى: باستخدام Docker (الأسهل)

```bash
# استنساخ المشروع
git clone <repository-url>
cd 3d-web-app

# تشغيل جميع الخدمات
docker-compose up -d

# انتظار بدء الخدمات (30-60 ثانية)
docker-compose logs -f

# فتح التطبيق
open http://localhost:3000
```

### الطريقة الثانية: التثبيت اليدوي

#### 1. إعداد قواعد البيانات

```bash
# تثبيت PostgreSQL
# Ubuntu/Debian:
sudo apt install postgresql postgresql-contrib postgis

# macOS:
brew install postgresql postgis

# إنشاء قاعدة البيانات
sudo -u postgres psql
CREATE DATABASE 3d_web_app;
\q

# تشغيل سكريبت الإعداد
psql -U postgres -d 3d_web_app -f backend/init-db.sql

# تثبيت وتشغيل Redis
# Ubuntu/Debian:
sudo apt install redis-server
sudo systemctl start redis-server

# macOS:
brew install redis
brew services start redis
```

#### 2. إعداد Backend

```bash
cd backend

# تثبيت التبعيات
npm install

# إنشاء ملف البيئة
cp .env.example .env

# تحرير الإعدادات (اختياري)
nano .env

# تشغيل الخادم
npm run dev
```

#### 3. إعداد Frontend

```bash
# في terminal جديد
cd frontend

# تثبيت التبعيات
npm install

# تشغيل التطبيق
npm run dev
```

#### 4. الوصول للتطبيق

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:4000/api
- **GraphQL Playground**: http://localhost:4000/graphql

## 🧪 اختبار التطبيق

### تسجيل مستخدم جديد
```bash
curl -X POST http://localhost:4000/graphql \
  -H "Content-Type: application/json" \
  -d '{
    "query": "mutation { register(input: { username: \"test\", email: \"test@example.com\", password: \"password123\", fullName: \"مستخدم تجريبي\" }) { token user { id username } } }"
  }'
```

### إنشاء مشروع جديد
```javascript
// في console المتصفح
fetch('http://localhost:4000/graphql', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_TOKEN_HERE'
  },
  body: JSON.stringify({
    query: `
      mutation {
        createProject(input: {
          name: "مشروعي الأول"
          description: "مشروع للاختبار"
          isPublic: true
        }) {
          id
          name
          createdAt
        }
      }
    `
  })
})
.then(r => r.json())
.then(console.log)
```

## 🛠 الأوامر المفيدة

### Docker
```bash
# إعادة بناء الصور
docker-compose build

# عرض الحالة
docker-compose ps

# عرض السجلات
docker-compose logs -f [service_name]

# إيقاف الخدمات
docker-compose down

# تنظيف البيانات
docker-compose down -v
```

### التطوير
```bash
# Frontend
cd frontend
npm run dev      # تشغيل التطوير
npm run build    # بناء للإنتاج
npm run start    # تشغيل الإنتاج
npm run lint     # فحص الكود

# Backend
cd backend
npm run dev      # تشغيل مع nodemon
npm start        # تشغيل عادي
npm test         # تشغيل الاختبارات
```

### قاعدة البيانات
```bash
# الاتصال بقاعدة البيانات
psql -U postgres -d 3d_web_app

# عمل backup
pg_dump -U postgres 3d_web_app > backup.sql

# استعادة backup
psql -U postgres -d 3d_web_app < backup.sql

# مراقبة Redis
redis-cli monitor
```

## 🔧 حل المشاكل الشائعة

### المشكلة: Frontend لا يتصل بـ Backend
```bash
# تحقق من تشغيل Backend
curl http://localhost:4000/health

# تحقق من إعدادات CORS في .env
FRONTEND_URL=http://localhost:3000
```

### المشكلة: خطأ في قاعدة البيانات
```bash
# تحقق من تشغيل PostgreSQL
sudo systemctl status postgresql

# تحقق من الاتصال
psql -U postgres -c "SELECT version();"

# إعادة تشغيل
sudo systemctl restart postgresql
```

### المشكلة: خطأ في Redis
```bash
# تحقق من تشغيل Redis
redis-cli ping

# إعادة تشغيل
sudo systemctl restart redis-server
```

### المشكلة: منافذ مشغولة
```bash
# التحقق من المنافذ المستخدمة
lsof -i :3000
lsof -i :4000
lsof -i :5432

# قتل العمليات المتداخلة
kill -9 <PID>
```

## 🌟 الميزات الأساسية للاختبار

### 1. عرض النماذج ثلاثية الأبعاد
- افتح http://localhost:3000
- ستشاهد مشهد تفاعلي بكائنات ثلاثية الأبعاد
- استخدم الماوس للتنقل (سحب للدوران، عجلة للتكبير)

### 2. واجهة المستخدم
- شريط علوي مع أدوات التنقل
- لوحة تحكم جانبية (قابلة للطي)
- شريط أدوات للتفاعل مع الكائنات
- شريط حالة في الأسفل

### 3. WebSocket (التعاون المباشر)
```javascript
// اختبار WebSocket
const ws = new WebSocket('ws://localhost:4000')
ws.onopen = () => console.log('متصل بـ WebSocket')
ws.onmessage = (e) => console.log('رسالة:', JSON.parse(e.data))
```

### 4. GraphQL API
- افتح http://localhost:4000/graphql
- جرب الاستعلامات التالية:

```graphql
# الحصول على جميع المشاريع العامة
query {
  publicProjects {
    id
    name
    description
    createdAt
  }
}

# الحصول على جميع النماذج العامة
query {
  publicModels {
    id
    name
    fileType
    downloadCount
  }
}
```

## 📱 اختبار على الأجهزة المختلفة

### الهاتف المحمول
```bash
# معرفة IP المحلي
ipconfig getifaddr en0  # macOS
hostname -I             # Linux

# فتح من الهاتف
http://192.168.1.x:3000
```

### أداء الشبكة
```bash
# قياس سرعة التحميل
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:3000
```

## 🔄 التحديث والصيانة

### تحديث التبعيات
```bash
# Frontend
cd frontend && npm update

# Backend  
cd backend && npm update
```

### نسخ احتياطية منتظمة
```bash
# سكريبت backup تلقائي
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -U postgres 3d_web_app > "backup_${DATE}.sql"
tar -czf "uploads_${DATE}.tar.gz" backend/uploads/
```

---

## 🆘 طلب المساعدة

إذا واجهت مشاكل:

1. تحقق من السجلات: `docker-compose logs -f`
2. راجع الوثائق الكاملة في `README.md`
3. افتح issue في GitHub
4. تواصل مع الفريق: support@example.com

**ملاحظة**: هذا دليل البدء السريع. للإعدادات المتقدمة والنشر في الإنتاج، راجع الوثائق الكاملة.
