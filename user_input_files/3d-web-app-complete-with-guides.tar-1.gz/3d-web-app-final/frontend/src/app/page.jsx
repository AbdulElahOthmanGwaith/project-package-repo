'use client'

import { Suspense } from 'react'
import Scene3D from '@/components/Scene3D'
import UI from '@/components/UI'
import LoadingSpinner from '@/components/LoadingSpinner'

export default function Home() {
  return (
    <main className="w-full h-screen relative">
      <div className="scene-container">
        <Suspense fallback={<LoadingSpinner />}>
          <Scene3D />
        </Suspense>
        <div className="ui-overlay">
          <UI />
        </div>
      </div>
    </main>
  )
}
