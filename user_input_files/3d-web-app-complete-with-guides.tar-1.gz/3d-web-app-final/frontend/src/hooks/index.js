import { useEffect, useRef, useState } from 'react'

// خطاف لتتبع FPS
export const useFPS = () => {
  const [fps, setFPS] = useState(60)
  const frameCount = useRef(0)
  const lastTime = useRef(Date.now())

  useEffect(() => {
    const updateFPS = () => {
      frameCount.current++
      const now = Date.now()
      const delta = now - lastTime.current

      if (delta >= 1000) {
        setFPS(Math.round((frameCount.current * 1000) / delta))
        frameCount.current = 0
        lastTime.current = now
      }

      requestAnimationFrame(updateFPS)
    }

    requestAnimationFrame(updateFPS)
  }, [])

  return fps
}

// خطاف لإدارة حالة المؤشر
export const useCursor = () => {
  const [cursor, setCursor] = useState('default')

  const setCursorStyle = (style: string) => {
    setCursor(style)
    document.body.style.cursor = style
  }

  useEffect(() => {
    return () => {
      document.body.style.cursor = 'default'
    }
  }, [])

  return { cursor, setCursorStyle }
}

// خطاف للتحكم بالكاميرا
export const useCamera = () => {
  const [cameraPosition, setCameraPosition] = useState<[number, number, number]>([5, 5, 5])
  const [target, setTarget] = useState<[number, number, number]>([0, 0, 0])

  const resetCamera = () => {
    setCameraPosition([5, 5, 5])
    setTarget([0, 0, 0])
  }

  const focusOnObject = (position: [number, number, number]) => {
    setTarget(position)
    const offset: [number, number, number] = [
      position[0] + 5,
      position[1] + 5,
      position[2] + 5
    ]
    setCameraPosition(offset)
  }

  return {
    cameraPosition,
    target,
    setCameraPosition,
    setTarget,
    resetCamera,
    focusOnObject
  }
}

// خطاف لتحميل النماذج ثلاثية الأبعاد
export const useModelLoader = () => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const loadModel = async (url: string): Promise<any> => {
    setLoading(true)
    setError(null)

    try {
      // هنا سيتم إضافة منطق تحميل النماذج لاحقاً
      // باستخدام GLTFLoader أو مكتبات أخرى
      await new Promise(resolve => setTimeout(resolve, 1000)) // محاكاة التحميل
      
      setLoading(false)
      return { success: true }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطأ في تحميل النموذج')
      setLoading(false)
      throw err
    }
  }

  return { loadModel, loading, error }
}

// خطاف لإدارة التفاعلات
export const useInteractions = () => {
  const [hoveredObject, setHoveredObject] = useState<string | null>(null)
  const [draggedObject, setDraggedObject] = useState<string | null>(null)

  const handlePointerOver = (objectId: string) => {
    setHoveredObject(objectId)
  }

  const handlePointerOut = () => {
    setHoveredObject(null)
  }

  const handleDragStart = (objectId: string) => {
    setDraggedObject(objectId)
  }

  const handleDragEnd = () => {
    setDraggedObject(null)
  }

  return {
    hoveredObject,
    draggedObject,
    handlePointerOver,
    handlePointerOut,
    handleDragStart,
    handleDragEnd
  }
}

// خطاف للتحكم بالشاشة الكاملة
export const useFullscreen = () => {
  const [isFullscreen, setIsFullscreen] = useState(false)

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen()
      setIsFullscreen(true)
    } else {
      await document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener('fullscreenchange', handleFullscreenChange)
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange)
    }
  }, [])

  return { isFullscreen, toggleFullscreen }
}
