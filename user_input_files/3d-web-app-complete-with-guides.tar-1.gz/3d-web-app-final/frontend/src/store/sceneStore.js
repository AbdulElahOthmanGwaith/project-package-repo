import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'

const defaultSceneSettings = {
  backgroundColor: '#1a1a1a',
  fogEnabled: false,
  fogIntensity: 20,
  gridVisible: true,
  shadowsEnabled: true,
  ambientLightIntensity: 0.4,
  directionalLightIntensity: 1,
  directionalLightColor: '#ffffff'
}

export const useSceneStore = create(
  subscribeWithSelector((set, get) => ({
    // الحالة الأولية
    models: [],
    selectedModel: null,
    sceneSettings: defaultSceneSettings,
    isLoading: false,
    activeTool: 'select',
    
    // إجراءات النماذج
    addModel: (modelData) => {
      const newModel = {
        id: crypto.randomUUID(),
        ...modelData
      }
      
      set((state) => ({
        models: [...state.models, newModel]
      }))
    },
    
    removeModel: (id) => {
      set((state) => ({
        models: state.models.filter(model => model.id !== id),
        selectedModel: state.selectedModel === id ? null : state.selectedModel
      }))
    },
    
    updateModel: (id, updates) => {
      set((state) => ({
        models: state.models.map(model =>
          model.id === id ? { ...model, ...updates } : model
        )
      }))
    },
    
    selectModel: (id) => {
      set((state) => ({
        selectedModel: id,
        models: state.models.map(model => ({
          ...model,
          selected: model.id === id
        }))
      }))
    },
    
    // إعدادات المشهد
    updateSceneSettings: (settings) => {
      set((state) => ({
        sceneSettings: { ...state.sceneSettings, ...settings }
      }))
    },
    
    // حالة التطبيق
    setLoading: (loading) => set({ isLoading: loading }),
    setActiveTool: (tool) => set({ activeTool: tool })
  }))
)

// وسائل مساعدة للاشتراك في التغييرات
export const useSelectedModel = () => {
  return useSceneStore((state) => {
    const selected = state.models.find(model => model.selected)
    return selected || null
  })
}

export const useSceneSettings = () => {
  return useSceneStore((state) => state.sceneSettings)
}

// خطاف مخصص لتتبع التغييرات
export const useModelUpdates = (modelId) => {
  return useSceneStore((state) => 
    state.models.find(model => model.id === modelId)
  )
}

