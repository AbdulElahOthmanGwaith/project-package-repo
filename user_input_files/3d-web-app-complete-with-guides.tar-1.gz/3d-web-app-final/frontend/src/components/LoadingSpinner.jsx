'use client'

export default function LoadingSpinner() {
  return (
    <div className="fixed inset-0 bg-gray-900 flex items-center justify-center z-50">
      <div className="text-center">
        <div className="loading-spinner w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full mb-4"></div>
        <p className="text-white text-lg">جاري تحميل المشهد ثلاثي الأبعاد...</p>
        <p className="text-gray-400 text-sm mt-2">يرجى الانتظار</p>
      </div>
    </div>
  )
}
