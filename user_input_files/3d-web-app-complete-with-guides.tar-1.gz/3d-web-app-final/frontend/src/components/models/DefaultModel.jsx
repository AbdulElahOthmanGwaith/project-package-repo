'use client'

import { useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { Mesh } from 'three'
import { Text } from '@react-three/drei'

export default function DefaultModel() {
  const meshRef = useRef<Mesh>(null)
  const [hovered, setHover] = useState(false)
  const [clicked, setClick] = useState(false)

  // دوران تلقائي للكائن
  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += delta * 0.2
      meshRef.current.rotation.y += delta * 0.3
    }
  })

  return (
    <group>
      {/* مكعب ثلاثي الأبعاد تفاعلي */}
      <mesh
        ref={meshRef}
        position={[0, 2, 0]}
        scale={clicked ? 1.5 : 1}
        onClick={() => setClick(!clicked)}
        onPointerOver={() => setHover(true)}
        onPointerOut={() => setHover(false)}
        castShadow
        receiveShadow
      >
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial
          color={hovered ? '#ff6b6b' : '#4ecdc4'}
          metalness={0.2}
          roughness={0.1}
        />
      </mesh>

      {/* كرة ثلاثية الأبعاد */}
      <mesh position={[-2, 1, 0]} castShadow>
        <sphereGeometry args={[0.8, 32, 32]} />
        <meshStandardMaterial
          color="#45b7d1"
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* أسطوانة */}
      <mesh position={[2, 1, 0]} castShadow>
        <cylinderGeometry args={[0.6, 0.6, 1.5, 32]} />
        <meshStandardMaterial
          color="#96ceb4"
          metalness={0.1}
          roughness={0.8}
        />
      </mesh>

      {/* مستوى للظلال */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0, 0]}
        receiveShadow
      >
        <planeGeometry args={[20, 20]} />
        <shadowMaterial opacity={0.3} />
      </mesh>

      {/* نص ثلاثي الأبعاد */}
      <Text
        position={[0, 4, 0]}
        fontSize={0.8}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineColor="black"
        outlineWidth={0.02}
      >
        تطبيق الويب ثلاثي الأبعاد
      </Text>

      <Text
        position={[0, 3.3, 0]}
        fontSize={0.4}
        color="#dddddd"
        anchorX="center"
        anchorY="middle"
      >
        اضغط على المكعب للتفاعل
      </Text>
    </group>
  )
}
