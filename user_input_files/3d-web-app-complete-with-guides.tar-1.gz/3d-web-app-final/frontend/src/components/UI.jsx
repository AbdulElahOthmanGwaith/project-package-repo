'use client'

import { useState } from 'react'
import { Menu, Settings, Upload, Download, Eye, EyeOff } from 'lucide-react'
import ControlPanel from './ui/ControlPanel'
import ToolBar from './ui/ToolBar'
import StatusBar from './ui/StatusBar'

export default function UI() {
  const [showControlPanel, setShowControlPanel] = useState(true)
  const [showGrid, setShowGrid] = useState(true)

  return (
    <>
      {/* شريط العلوي */}
      <header className="absolute top-0 left-0 right-0 bg-black/80 backdrop-blur-sm text-white p-4 z-20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 space-x-reverse">
            <button
              onClick={() => setShowControlPanel(!showControlPanel)}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="عرض/إخفاء لوحة التحكم"
            >
              <Menu size={20} />
            </button>
            <h1 className="text-xl font-bold">
              تطبيق الويب ثلاثي الأبعاد
            </h1>
          </div>
          
          <div className="flex items-center space-x-2 space-x-reverse">
            <button
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="تحميل نموذج"
            >
              <Upload size={20} />
            </button>
            <button
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="تصدير المشهد"
            >
              <Download size={20} />
            </button>
            <button
              onClick={() => setShowGrid(!showGrid)}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="عرض/إخفاء الشبكة"
            >
              {showGrid ? <Eye size={20} /> : <EyeOff size={20} />}
            </button>
            <button
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="الإعدادات"
            >
              <Settings size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* لوحة التحكم الجانبية */}
      {showControlPanel && <ControlPanel />}

      {/* شريط الأدوات */}
      <ToolBar />

      {/* شريط الحالة */}
      <StatusBar />
    </>
  )
}
