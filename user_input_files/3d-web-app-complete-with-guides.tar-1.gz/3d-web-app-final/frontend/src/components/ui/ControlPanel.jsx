'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight, Palette, Sun, Layers } from 'lucide-react'

export default function ControlPanel() {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [activeTab, setActiveTab] = useState('scene')

  return (
    <div className={`fixed right-0 top-16 h-[calc(100vh-4rem)] bg-black/90 backdrop-blur-sm text-white transition-all duration-300 z-10 ${
      isCollapsed ? 'w-12' : 'w-80'
    }`}>
      {/* زر الطي والتوسيع */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-black/80 hover:bg-black p-1 rounded-full border border-gray-600"
      >
        {isCollapsed ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
      </button>

      {!isCollapsed && (
        <div className="p-4 h-full flex flex-col">
          {/* علامات التبويب */}
          <div className="flex border-b border-gray-700 mb-4">
            {[
              { id: 'scene', label: 'المشهد', icon: Layers },
              { id: 'lighting', label: 'الإضاءة', icon: Sun },
              { id: 'materials', label: 'المواد', icon: Palette }
            ].map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 py-2 px-3 text-sm transition-colors flex items-center justify-center space-x-2 space-x-reverse ${
                    activeTab === tab.id 
                      ? 'border-b-2 border-blue-500 text-blue-400' 
                      : 'hover:bg-white/10'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>

          {/* محتوى علامات التبويب */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'scene' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">إعدادات المشهد</h3>
                
                <div>
                  <label className="block text-sm mb-2">لون الخلفية</label>
                  <input
                    type="color"
                    defaultValue="#1a1a1a"
                    className="w-full h-10 border border-gray-600 rounded"
                  />
                </div>

                <div>
                  <label className="block text-sm mb-2">الضباب</label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    defaultValue="20"
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="flex items-center space-x-2 space-x-reverse">
                    <input type="checkbox" defaultChecked />
                    <span>عرض الشبكة</span>
                  </label>
                </div>

                <div>
                  <label className="flex items-center space-x-2 space-x-reverse">
                    <input type="checkbox" defaultChecked />
                    <span>عرض الظلال</span>
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'lighting' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">إعدادات الإضاءة</h3>
                
                <div>
                  <label className="block text-sm mb-2">شدة الإضاءة المحيطية</label>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    defaultValue="0.4"
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm mb-2">شدة الضوء الرئيسي</label>
                  <input
                    type="range"
                    min="0"
                    max="3"
                    step="0.1"
                    defaultValue="1"
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm mb-2">لون الضوء الرئيسي</label>
                  <input
                    type="color"
                    defaultValue="#ffffff"
                    className="w-full h-10 border border-gray-600 rounded"
                  />
                </div>
              </div>
            )}

            {activeTab === 'materials' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">إعدادات المواد</h3>
                
                <div>
                  <label className="block text-sm mb-2">اللون الأساسي</label>
                  <input
                    type="color"
                    defaultValue="#4ecdc4"
                    className="w-full h-10 border border-gray-600 rounded"
                  />
                </div>

                <div>
                  <label className="block text-sm mb-2">المعدنية</label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    defaultValue="0.2"
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm mb-2">الخشونة</label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    defaultValue="0.1"
                    className="w-full"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
