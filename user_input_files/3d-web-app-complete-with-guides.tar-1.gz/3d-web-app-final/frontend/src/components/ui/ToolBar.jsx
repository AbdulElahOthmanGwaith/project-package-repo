'use client'

import { useState } from 'react'
import { 
  Move, 
  RotateCcw, 
  Scale, 
  MousePointer, 
  Box, 
  Sphere, 
  Cylinder,
  Trash2,
  Copy
} from 'lucide-react'

export default function ToolBar() {
  const [activeTool, setActiveTool] = useState('select')

  const tools = [
    { id: 'select', icon: MousePointer, label: 'تحديد' },
    { id: 'move', icon: Move, label: 'نقل' },
    { id: 'rotate', icon: RotateCcw, label: 'دوران' },
    { id: 'scale', icon: Scale, label: 'تغيير الحجم' },
  ]

  const primitives = [
    { id: 'cube', icon: Box, label: 'مكعب' },
    { id: 'sphere', icon: Sphere, label: 'كرة' },
    { id: 'cylinder', icon: Cylinder, label: 'أسطوانة' },
  ]

  const actions = [
    { id: 'copy', icon: Copy, label: 'نسخ' },
    { id: 'delete', icon: Trash2, label: 'حذف' },
  ]

  return (
    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/80 backdrop-blur-sm rounded-lg p-2 z-10">
      <div className="flex flex-col space-y-1">
        {/* أدوات التحكم */}
        <div className="border-b border-gray-700 pb-2 mb-2">
          {tools.map((tool) => {
            const Icon = tool.icon
            return (
              <button
                key={tool.id}
                onClick={() => setActiveTool(tool.id)}
                className={`w-10 h-10 flex items-center justify-center rounded-lg transition-colors mb-1 ${
                  activeTool === tool.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-white/10'
                }`}
                title={tool.label}
              >
                <Icon size={20} />
              </button>
            )
          })}
        </div>

        {/* الأشكال الأساسية */}
        <div className="border-b border-gray-700 pb-2 mb-2">
          {primitives.map((primitive) => {
            const Icon = primitive.icon
            return (
              <button
                key={primitive.id}
                className="w-10 h-10 flex items-center justify-center rounded-lg transition-colors mb-1 text-gray-400 hover:text-white hover:bg-white/10"
                title={primitive.label}
              >
                <Icon size={20} />
              </button>
            )
          })}
        </div>

        {/* الإجراءات */}
        <div>
          {actions.map((action) => {
            const Icon = action.icon
            return (
              <button
                key={action.id}
                className="w-10 h-10 flex items-center justify-center rounded-lg transition-colors mb-1 text-gray-400 hover:text-white hover:bg-white/10"
                title={action.label}
              >
                <Icon size={20} />
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
