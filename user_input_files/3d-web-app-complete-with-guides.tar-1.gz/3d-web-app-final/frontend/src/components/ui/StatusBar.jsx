'use client'

import { useState, useEffect } from 'react'
import { Monitor, Cpu, HardDrive } from 'lucide-react'

export default function StatusBar() {
  const [fps, setFps] = useState(60)
  const [triangles, setTriangles] = useState(0)
  const [selectedObject, setSelectedObject] = useState<string | null>(null)

  // محاكاة إحصائيات FPS
  useEffect(() => {
    const interval = setInterval(() => {
      setFps(Math.floor(Math.random() * 10) + 55) // محاكاة FPS بين 55-65
      setTriangles(Math.floor(Math.random() * 1000) + 5000) // محاكاة عدد المثلثات
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="absolute bottom-0 left-0 right-0 bg-black/80 backdrop-blur-sm text-white p-2 z-10">
      <div className="flex items-center justify-between text-sm">
        {/* معلومات الأداء */}
        <div className="flex items-center space-x-6 space-x-reverse">
          <div className="flex items-center space-x-2 space-x-reverse">
            <Monitor size={14} />
            <span>FPS: {fps}</span>
          </div>
          
          <div className="flex items-center space-x-2 space-x-reverse">
            <Cpu size={14} />
            <span>مثلثات: {triangles.toLocaleString()}</span>
          </div>
          
          <div className="flex items-center space-x-2 space-x-reverse">
            <HardDrive size={14} />
            <span>الذاكرة: 145 MB</span>
          </div>
        </div>

        {/* معلومات الكائن المحدد */}
        <div className="flex items-center space-x-4 space-x-reverse">
          {selectedObject && (
            <div className="text-blue-400">
              محدد: {selectedObject}
            </div>
          )}
          
          <div className="text-gray-400">
            الموقع: X: 0.0, Y: 2.0, Z: 0.0
          </div>
          
          <div className="text-gray-400">
            WebGL 2.0
          </div>
        </div>
      </div>
    </div>
  )
}
