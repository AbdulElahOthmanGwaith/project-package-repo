'use client'

import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { DirectionalLight, Group } from 'three'

export default function Lighting() {
  const directionalLightRef = useRef<DirectionalLight>(null)
  const groupRef = useRef<Group>(null)

  // تحريك الضوء تلقائياً لإضافة ديناميكية للمشهد
  useFrame((state) => {
    if (directionalLightRef.current) {
      const time = state.clock.getElapsedTime()
      directionalLightRef.current.position.x = Math.sin(time * 0.5) * 10
      directionalLightRef.current.position.z = Math.cos(time * 0.5) * 10
    }
  })

  return (
    <group ref={groupRef}>
      {/* الإضاءة المحيطية */}
      <ambientLight intensity={0.4} color="#f0f0f0" />
      
      {/* الإضاءة الاتجاهية الرئيسية */}
      <directionalLight
        ref={directionalLightRef}
        position={[10, 10, 5]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={10}
        shadow-camera-bottom={-10}
      />
      
      {/* إضاءة إضافية للتفاصيل */}
      <pointLight position={[-10, -10, -10]} intensity={0.3} color="#4080ff" />
      <pointLight position={[10, -10, 10]} intensity={0.3} color="#ff8040" />
      
      {/* إضاءة ملء للظلال */}
      <hemisphereLight
        skyColor="#87CEEB"
        groundColor="#362d1d"
        intensity={0.5}
      />
    </group>
  )
}
