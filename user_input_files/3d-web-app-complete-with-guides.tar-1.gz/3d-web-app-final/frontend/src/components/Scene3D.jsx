'use client'

import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment, PerspectiveCamera, Grid } from '@react-three/drei'
import { Suspense } from 'react'
import DefaultModel from './models/DefaultModel'
import Lighting from './Lighting'
import { useSceneStore } from '@/store/sceneStore'

export default function Scene3D() {
  const { models, selectedModel } = useSceneStore()

  return (
    <Canvas
      gl={{ antialias: true, alpha: false }}
      shadows
      className="w-full h-full"
    >
      {/* الكاميرا */}
      <PerspectiveCamera makeDefault position={[5, 5, 5]} fov={60} />
      
      {/* التحكم بالكاميرا */}
      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        dampingFactor={0.05}
        minDistance={1}
        maxDistance={100}
      />

      {/* الإضاءة */}
      <Suspense fallback={null}>
        <Lighting />
      </Suspense>

      {/* البيئة المحيطة */}
      <Suspense fallback={null}>
        <Environment preset="city" background={false} />
      </Suspense>

      {/* الشبكة الأساسية */}
      <Grid
        args={[20, 20]}
        cellSize={1}
        cellThickness={0.5}
        cellColor="#e0e0e0"
        sectionSize={10}
        sectionThickness={1}
        sectionColor="#a0a0a0"
        fadeDistance={100}
        fadeStrength={1}
        followCamera={false}
        infiniteGrid={true}
      />

      {/* النماذج ثلاثية الأبعاد */}
      <Suspense fallback={null}>
        {models.length === 0 ? (
          <DefaultModel />
        ) : (
          models.map((model) => (
            <group key={model.id}>
              {/* هنا سيتم إضافة النماذج المحملة لاحقاً */}
            </group>
          ))
        )}
      </Suspense>
    </Canvas>
  )
}
