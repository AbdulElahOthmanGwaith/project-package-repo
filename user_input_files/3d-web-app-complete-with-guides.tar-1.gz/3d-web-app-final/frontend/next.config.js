/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  webpack: (config) => {
    // إعداد خاص لمكتبة Three.js
    config.externals = config.externals || [];
    config.externals.push({
      'three': 'THREE'
    });
    return config;
  }
}

module.exports = nextConfig
