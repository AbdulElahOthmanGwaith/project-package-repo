# PowerShell Script لفحص متطلبات تطبيق الويب ثلاثي الأبعاد
# 3D Web App Requirements Checker for Windows

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "🔍 فحص متطلبات تشغيل تطبيق الويب ثلاثي الأبعاد" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Error {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Blue
}

# فحص Node.js
Write-Host "`n📦 فحص Node.js..." -ForegroundColor White
try {
    $nodeVersion = & node --version 2>$null
    if ($nodeVersion) {
        Write-Success "Node.js مثبت - النسخة: $nodeVersion"
        
        # فحص النسخة
        $majorVersion = [int]($nodeVersion -replace 'v(\d+)\..*', '$1')
        if ($majorVersion -ge 18) {
            Write-Success "نسخة Node.js مدعومة"
        } else {
            Write-Warning "يُنصح بترقية Node.js إلى نسخة 18 أو أحدث"
        }
    }
} catch {
    Write-Error "Node.js غير مثبت"
    Write-Info "قم بتثبيت Node.js من: https://nodejs.org/"
}

# فحص NPM
Write-Host "`n📦 فحص NPM..." -ForegroundColor White
try {
    $npmVersion = & npm --version 2>$null
    if ($npmVersion) {
        Write-Success "NPM مثبت - النسخة: $npmVersion"
    }
} catch {
    Write-Error "NPM غير مثبت"
}

# فحص Docker
Write-Host "`n🐳 فحص Docker..." -ForegroundColor White
try {
    $dockerVersion = & docker --version 2>$null
    if ($dockerVersion) {
        Write-Success "Docker مثبت - $dockerVersion"
        
        # فحص تشغيل Docker
        try {
            & docker info 2>$null | Out-Null
            if ($LASTEXITCODE -eq 0) {
                Write-Success "Docker يعمل بشكل صحيح"
            } else {
                Write-Warning "Docker مثبت لكنه لا يعمل. تأكد من تشغيل Docker Desktop"
            }
        } catch {
            Write-Warning "Docker مثبت لكنه لا يعمل. تأكد من تشغيل Docker Desktop"
        }
    }
} catch {
    Write-Error "Docker غير مثبت"
    Write-Info "تثبيت Docker سيجعل عملية التشغيل أسهل"
}

# فحص Docker Compose
Write-Host "`n🐳 فحص Docker Compose..." -ForegroundColor White
try {
    $composeVersion = & docker-compose --version 2>$null
    if ($composeVersion) {
        Write-Success "Docker Compose مثبت - $composeVersion"
    } else {
        try {
            $composeV2Version = & docker compose version 2>$null
            if ($composeV2Version) {
                Write-Success "Docker Compose (v2) مثبت - $composeV2Version"
            }
        } catch {
            Write-Error "Docker Compose غير مثبت"
        }
    }
} catch {
    Write-Error "Docker Compose غير مثبت"
}

# فحص المنافذ
Write-Host "`n🌐 فحص المنافذ..." -ForegroundColor White
$portsToCheck = @(3000, 4000, 5432, 6379)
$occupiedPorts = @()

foreach ($port in $portsToCheck) {
    $connection = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
    if ($connection) {
        $occupiedPorts += $port
        Write-Warning "المنفذ $port مُستخدم"
    } else {
        Write-Success "المنفذ $port متاح"
    }
}

# فحص Git
Write-Host "`n📁 فحص Git..." -ForegroundColor White
try {
    $gitVersion = & git --version 2>$null
    if ($gitVersion) {
        Write-Success "Git مثبت - $gitVersion"
    }
} catch {
    Write-Warning "Git غير مثبت - مفيد لإدارة المشروع"
}

# التوصيات
Write-Host "`n🎯 التوصيات:" -ForegroundColor Cyan
Write-Host "==============" -ForegroundColor Cyan

$dockerAvailable = $false
try {
    & docker --version 2>$null | Out-Null
    & docker info 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
        $dockerAvailable = $true
    }
} catch { }

if ($dockerAvailable) {
    Write-Success "يمكنك استخدام Docker لتشغيل التطبيق بسهولة!"
    Write-Host ""
    Write-Host "الأوامر:" -ForegroundColor Yellow
    Write-Host "  cd 3d-web-app" -ForegroundColor Gray
    Write-Host "  docker-compose up -d" -ForegroundColor Gray
    Write-Host ""
    Write-Host "بعد ذلك افتح: http://localhost:3000" -ForegroundColor Green
} else {
    try {
        & node --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Warning "يمكنك تشغيل التطبيق يدوياً لكن ستحتاج PostgreSQL و Redis"
            Write-Host ""
            Write-Host "أو قم بتثبيت Docker Desktop للتشغيل الأسهل:" -ForegroundColor Yellow
            Write-Host "https://www.docker.com/products/docker-desktop/" -ForegroundColor Blue
        }
    } catch {
        Write-Error "تحتاج لتثبيت Node.js أولاً"
        Write-Host "زر: https://nodejs.org/" -ForegroundColor Blue
    }
}

if ($occupiedPorts.Count -gt 0) {
    Write-Host ""
    Write-Warning "منافذ مُستخدمة: $($occupiedPorts -join ', ')"
    Write-Host "لعرض العمليات المستخدمة للمنافذ:" -ForegroundColor Yellow
    foreach ($port in $occupiedPorts) {
        Write-Host "  Get-NetTCPConnection -LocalPort $port | Select-Object OwningProcess" -ForegroundColor Gray
    }
}

# معلومات النظام
Write-Host "`n💻 معلومات النظام:" -ForegroundColor Cyan
Write-Host "=================" -ForegroundColor Cyan
Write-Host "نظام التشغيل: $($PSVersionTable.PSVersion)" -ForegroundColor Gray
Write-Host "PowerShell: $($PSVersionTable.PSVersion)" -ForegroundColor Gray

# أوامر مفيدة
Write-Host "`n🛠  أوامر مفيدة لـ PowerShell:" -ForegroundColor Cyan
Write-Host "============================" -ForegroundColor Cyan
Write-Host "فحص المنافذ المُستخدمة:" -ForegroundColor Yellow
Write-Host "  Get-NetTCPConnection | Where-Object {`$_.LocalPort -in @(3000,4000)} | Select-Object LocalPort,OwningProcess" -ForegroundColor Gray
Write-Host ""
Write-Host "إيقاف عملية برقم PID:" -ForegroundColor Yellow
Write-Host "  Stop-Process -Id [رقم_العملية] -Force" -ForegroundColor Gray
Write-Host ""
Write-Host "فحص Docker:" -ForegroundColor Yellow
Write-Host "  docker ps" -ForegroundColor Gray
Write-Host "  docker-compose ps" -ForegroundColor Gray
Write-Host ""

Write-Host "انتهى الفحص! 🎉" -ForegroundColor Green
Write-Host ""
Read-Host "اضغط Enter للمتابعة"