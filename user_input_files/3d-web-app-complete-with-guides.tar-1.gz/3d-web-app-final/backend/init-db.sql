-- إعداد قاعدة البيانات الأولية
-- يتم تشغيل هذا الملف تلقائياً عند إنشاء قاعدة البيانات

-- تمكين إضافة PostGIS للبيانات المكانية
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;

-- تمكين إضافة uuid-ossp لتوليد UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- إنشاء مستخدم التطبيق مع الصلاحيات المناسبة
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'app_user') THEN
        CREATE ROLE app_user LOGIN PASSWORD 'app_password';
    END IF;
END
$$;

-- منح صلاحيات للمستخدم
GRANT CONNECT ON DATABASE 3d_web_app TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT CREATE ON SCHEMA public TO app_user;

-- إنشاء جدول المستخدمين
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء جدول المشاريع
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    is_public BOOLEAN DEFAULT FALSE,
    thumbnail_url TEXT,
    scene_data JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء جدول النماذج ثلاثية الأبعاد
CREATE TABLE IF NOT EXISTS models (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    file_url TEXT NOT NULL,
    file_size BIGINT,
    file_type VARCHAR(50),
    thumbnail_url TEXT,
    bounding_box JSONB,
    metadata JSONB DEFAULT '{}',
    owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    is_public BOOLEAN DEFAULT FALSE,
    download_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء جدول مشاركة المشاريع
CREATE TABLE IF NOT EXISTS project_collaborators (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(20) DEFAULT 'VIEWER' CHECK (role IN ('VIEWER', 'EDITOR', 'ADMIN')),
    permissions JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id, user_id)
);

-- إنشاء جدول جلسات التعاون المباشر
CREATE TABLE IF NOT EXISTS collaboration_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    host_id UUID REFERENCES users(id) ON DELETE CASCADE,
    session_name VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    max_participants INTEGER DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP
);

-- إنشاء جدول المشاركين في الجلسات
CREATE TABLE IF NOT EXISTS session_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID REFERENCES collaboration_sessions(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    cursor_position POINT,
    is_online BOOLEAN DEFAULT TRUE,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    left_at TIMESTAMP,
    UNIQUE(session_id, user_id)
);

-- إنشاء جدول تاريخ التغييرات
CREATE TABLE IF NOT EXISTS change_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    action_type VARCHAR(50) NOT NULL,
    object_id VARCHAR(100),
    old_data JSONB,
    new_data JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء الفهارس للأداء
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active);

CREATE INDEX IF NOT EXISTS idx_projects_owner ON projects(owner_id);
CREATE INDEX IF NOT EXISTS idx_projects_public ON projects(is_public);
CREATE INDEX IF NOT EXISTS idx_projects_updated ON projects(updated_at);

CREATE INDEX IF NOT EXISTS idx_models_owner ON models(owner_id);
CREATE INDEX IF NOT EXISTS idx_models_public ON models(is_public);
CREATE INDEX IF NOT EXISTS idx_models_type ON models(file_type);
CREATE INDEX IF NOT EXISTS idx_models_downloads ON models(download_count);

CREATE INDEX IF NOT EXISTS idx_collaborators_project ON project_collaborators(project_id);
CREATE INDEX IF NOT EXISTS idx_collaborators_user ON project_collaborators(user_id);
CREATE INDEX IF NOT EXISTS idx_collaborators_role ON project_collaborators(role);

CREATE INDEX IF NOT EXISTS idx_sessions_project ON collaboration_sessions(project_id);
CREATE INDEX IF NOT EXISTS idx_sessions_active ON collaboration_sessions(is_active);
CREATE INDEX IF NOT EXISTS idx_sessions_host ON collaboration_sessions(host_id);

CREATE INDEX IF NOT EXISTS idx_participants_session ON session_participants(session_id);
CREATE INDEX IF NOT EXISTS idx_participants_user ON session_participants(user_id);
CREATE INDEX IF NOT EXISTS idx_participants_online ON session_participants(is_online);

CREATE INDEX IF NOT EXISTS idx_history_project ON change_history(project_id);
CREATE INDEX IF NOT EXISTS idx_history_user ON change_history(user_id);
CREATE INDEX IF NOT EXISTS idx_history_action ON change_history(action_type);
CREATE INDEX IF NOT EXISTS idx_history_timestamp ON change_history(timestamp);

-- إنشاء فهارس البحث النصي
CREATE INDEX IF NOT EXISTS idx_projects_name_search ON projects USING gin(to_tsvector('arabic', name));
CREATE INDEX IF NOT EXISTS idx_models_name_search ON models USING gin(to_tsvector('arabic', name));

-- إنشاء trigger لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = CURRENT_TIMESTAMP;
   RETURN NEW;
END;
$$ language 'plpgsql';

-- تطبيق trigger على الجداول المناسبة
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_models_updated_at BEFORE UPDATE ON models 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- إنشاء بيانات تجريبية (للتطوير فقط)
DO $$
BEGIN
    -- إنشاء مستخدم تجريبي
    INSERT INTO users (username, email, password_hash, full_name) 
    VALUES (
        'admin', 
        'admin@example.com', 
        '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewkY5rJ.Jh4xaWCG', -- password: admin123
        'مدير النظام'
    ) ON CONFLICT (email) DO NOTHING;
    
    -- إنشاء مشروع تجريبي
    INSERT INTO projects (name, description, owner_id, is_public, scene_data)
    SELECT 
        'مشروع تجريبي',
        'مشروع للاختبار والتجريب',
        u.id,
        true,
        '{"objects": [], "settings": {"backgroundColor": "#1a1a1a"}}'
    FROM users u 
    WHERE u.email = 'admin@example.com'
    AND NOT EXISTS (SELECT 1 FROM projects WHERE name = 'مشروع تجريبي');

END $$;

-- منح صلاحيات كاملة لمستخدم التطبيق على جميع الجداول
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;

-- رسائل إتمام
SELECT 'تم إعداد قاعدة البيانات بنجاح!' as status;
