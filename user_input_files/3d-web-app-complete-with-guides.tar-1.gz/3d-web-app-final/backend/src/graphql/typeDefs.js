import { gql } from 'apollo-server-express'

export const typeDefs = gql`
  # الأنواع الأساسية
  scalar Upload
  scalar JSON
  scalar DateTime

  # المستخدم
  type User {
    id: ID!
    username: String!
    email: String!
    fullName: String
    avatarUrl: String
    isActive: Boolean!
    lastLogin: DateTime
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  # المشروع
  type Project {
    id: ID!
    name: String!
    description: String
    owner: User!
    isPublic: Boolean!
    thumbnailUrl: String
    sceneData: JSON
    collaborators: [Collaborator!]!
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  # النموذج ثلاثي الأبعاد
  type Model {
    id: ID!
    name: String!
    fileUrl: String!
    fileSize: Int
    fileType: String
    thumbnailUrl: String
    boundingBox: JSON
    metadata: JSON
    owner: User!
    isPublic: Boolean!
    downloadCount: Int!
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  # المتعاون
  type Collaborator {
    id: ID!
    project: Project!
    user: User!
    role: CollaboratorRole!
    permissions: JSON
    createdAt: DateTime!
  }

  # جلسة التعاون
  type CollaborationSession {
    id: ID!
    project: Project!
    host: User!
    sessionName: String
    isActive: Boolean!
    maxParticipants: Int!
    participants: [SessionParticipant!]!
    createdAt: DateTime!
    endedAt: DateTime
  }

  # المشارك في الجلسة
  type SessionParticipant {
    id: ID!
    session: CollaborationSession!
    user: User!
    cursorPosition: [Float!]
    isOnline: Boolean!
    joinedAt: DateTime!
    leftAt: DateTime
  }

  # سجل التغييرات
  type ChangeRecord {
    id: ID!
    project: Project!
    user: User!
    actionType: String!
    objectId: String
    oldData: JSON
    newData: JSON
    timestamp: DateTime!
  }

  # الأدوار
  enum CollaboratorRole {
    VIEWER
    EDITOR
    ADMIN
  }

  # المدخلات
  input CreateProjectInput {
    name: String!
    description: String
    isPublic: Boolean
    sceneData: JSON
  }

  input UpdateProjectInput {
    name: String
    description: String
    isPublic: Boolean
    sceneData: JSON
  }

  input CreateModelInput {
    name: String!
    file: Upload!
    isPublic: Boolean
    metadata: JSON
  }

  input UpdateModelInput {
    name: String
    isPublic: Boolean
    metadata: JSON
  }

  input AddCollaboratorInput {
    projectId: ID!
    userId: ID!
    role: CollaboratorRole!
    permissions: JSON
  }

  input CreateSessionInput {
    projectId: ID!
    sessionName: String
    maxParticipants: Int
  }

  input RegisterInput {
    username: String!
    email: String!
    password: String!
    fullName: String
  }

  input LoginInput {
    email: String!
    password: String!
  }

  # الاستعلامات
  type Query {
    # المستخدمين
    me: User
    users: [User!]!
    user(id: ID!): User

    # المشاريع
    projects: [Project!]!
    project(id: ID!): Project
    myProjects: [Project!]!
    publicProjects: [Project!]!

    # النماذج
    models: [Model!]!
    model(id: ID!): Model
    myModels: [Model!]!
    publicModels: [Model!]!

    # التعاون
    collaborationSessions: [CollaborationSession!]!
    activeSession(projectId: ID!): CollaborationSession

    # السجلات
    projectHistory(projectId: ID!, limit: Int, offset: Int): [ChangeRecord!]!
  }

  # الطفرات
  type Mutation {
    # المصادقة
    register(input: RegisterInput!): AuthPayload!
    login(input: LoginInput!): AuthPayload!
    logout: Boolean!

    # المشاريع
    createProject(input: CreateProjectInput!): Project!
    updateProject(id: ID!, input: UpdateProjectInput!): Project!
    deleteProject(id: ID!): Boolean!

    # النماذج
    uploadModel(input: CreateModelInput!): Model!
    updateModel(id: ID!, input: UpdateModelInput!): Model!
    deleteModel(id: ID!): Boolean!

    # التعاون
    addCollaborator(input: AddCollaboratorInput!): Collaborator!
    removeCollaborator(projectId: ID!, userId: ID!): Boolean!
    updateCollaboratorRole(projectId: ID!, userId: ID!, role: CollaboratorRole!): Collaborator!

    # الجلسات
    createSession(input: CreateSessionInput!): CollaborationSession!
    joinSession(sessionId: ID!): SessionParticipant!
    leaveSession(sessionId: ID!): Boolean!
    endSession(sessionId: ID!): Boolean!

    # إجراءات المشهد
    updateScene(projectId: ID!, sceneData: JSON!): Project!
    addObject(projectId: ID!, objectData: JSON!): Boolean!
    updateObject(projectId: ID!, objectId: String!, updates: JSON!): Boolean!
    deleteObject(projectId: ID!, objectId: String!): Boolean!
  }

  # الاشتراكات (للتحديثات المباشرة)
  type Subscription {
    # تحديثات المشروع
    projectUpdated(projectId: ID!): Project!
    
    # تحديثات المشهد
    sceneUpdated(projectId: ID!): JSON!
    
    # تحديثات المشاركين
    participantJoined(sessionId: ID!): SessionParticipant!
    participantLeft(sessionId: ID!): SessionParticipant!
    participantMoved(sessionId: ID!): SessionParticipant!
    
    # تحديثات الكائنات
    objectAdded(projectId: ID!): JSON!
    objectUpdated(projectId: ID!): JSON!
    objectDeleted(projectId: ID!): JSON!
  }

  # نوع المصادقة
  type AuthPayload {
    token: String!
    user: User!
  }
`
