import { GraphQLUpload } from 'graphql-upload'
import { GraphQLJSON, GraphQLDateTime } from 'graphql-scalars'
import { AuthenticationError, ForbiddenError, UserInputError } from 'apollo-server-express'

import * as userService from '../services/userService.js'
import * as projectService from '../services/projectService.js'
import * as modelService from '../services/modelService.js'
import * as collaborationService from '../services/collaborationService.js'
import { cacheUtils } from '../config/redis.js'

export const resolvers = {
  // تعريف الأنواع المخصصة
  Upload: GraphQLUpload,
  JSON: GraphQLJSON,
  DateTime: GraphQLDateTime,

  // الاستعلامات
  Query: {
    // المستخدمين
    me: async (parent, args, context) => {
      if (!context.user) {
        throw new AuthenticationError('يجب تسجيل الدخول أولاً')
      }
      return await userService.getUserById(context.user.id)
    },

    users: async () => {
      return await userService.getAllUsers()
    },

    user: async (parent, { id }) => {
      return await userService.getUserById(id)
    },

    // المشاريع
    projects: async () => {
      return await projectService.getAllProjects()
    },

    project: async (parent, { id }, context) => {
      const project = await projectService.getProjectById(id)
      
      if (!project.isPublic && (!context.user || !await projectService.hasAccess(context.user.id, id))) {
        throw new ForbiddenError('ليس لديك صلاحية لعرض هذا المشروع')
      }
      
      return project
    },

    myProjects: async (parent, args, context) => {
      if (!context.user) {
        throw new AuthenticationError('يجب تسجيل الدخول أولاً')
      }
      return await projectService.getUserProjects(context.user.id)
    },

    publicProjects: async () => {
      return await projectService.getPublicProjects()
    },

    // النماذج
    models: async () => {
      return await modelService.getAllModels()
    },

    model: async (parent, { id }) => {
      return await modelService.getModelById(id)
    },

    myModels: async (parent, args, context) => {
      if (!context.user) {
        throw new AuthenticationError('يجب تسجيل الدخول أولاً')
      }
      return await modelService.getUserModels(context.user.id)
    },

    publicModels: async () => {
      return await modelService.getPublicModels()
    },

    // التعاون
    collaborationSessions: async (parent, args, context) => {
      if (!context.user) {
        throw new AuthenticationError('يجب تسجيل الدخول أولاً')
      }
      return await collaborationService.getUserSessions(context.user.id)
    },

    activeSession: async (parent, { projectId }) => {
      return await collaborationService.getActiveSession(projectId)
    },

    // السجلات
    projectHistory: async (parent, { projectId, limit = 50, offset = 0 }, context) => {
      if (!context.user || !await projectService.hasAccess(context.user.id, projectId)) {
        throw new ForbiddenError('ليس لديك صلاحية لعرض تاريخ هذا المشروع')
      }
      return await projectService.getProjectHistory(projectId, limit, offset)
    }
  },

  // الطفرات
  Mutation: {
    // المصادقة
    register: async (parent, { input }) => {
      return await userService.register(input)
    },

    login: async (parent, { input }, context) => {
      const result = await userService.login(input)
      
      // حفظ الجلسة في Redis
      await cacheUtils.setSession(result.token, {
        userId: result.user.id,
        loginTime: new Date()
      })
      
      return result
    },

    logout: async (parent, args, context) => {
      if (context.user && context.req.headers.authorization) {
        const token = context.req.headers.authorization.replace('Bearer ', '')
        await cacheUtils.deleteSession(token)
      }
      return true
    },

    // المشاريع
    createProject: async (parent, { input }, context) => {
      if (!context.user) {
        throw new AuthenticationError('يجب تسجيل الدخول أولاً')
      }
      return await projectService.createProject({ ...input, ownerId: context.user.id })
    },

    updateProject: async (parent, { id, input }, context) => {
      if (!context.user || !await projectService.canEdit(context.user.id, id)) {
        throw new ForbiddenError('ليس لديك صلاحية لتعديل هذا المشروع')
      }
      
      const result = await projectService.updateProject(id, input)
      
      // تسجيل التغيير
      await projectService.logChange({
        projectId: id,
        userId: context.user.id,
        actionType: 'UPDATE_PROJECT',
        newData: input
      })
      
      return result
    },

    deleteProject: async (parent, { id }, context) => {
      if (!context.user || !await projectService.isOwner(context.user.id, id)) {
        throw new ForbiddenError('يمكن للمالك فقط حذف المشروع')
      }
      
      return await projectService.deleteProject(id)
    },

    // النماذج
    uploadModel: async (parent, { input }, context) => {
      if (!context.user) {
        throw new AuthenticationError('يجب تسجيل الدخول أولاً')
      }
      
      return await modelService.uploadModel({
        ...input,
        ownerId: context.user.id
      })
    },

    updateModel: async (parent, { id, input }, context) => {
      if (!context.user || !await modelService.isOwner(context.user.id, id)) {
        throw new ForbiddenError('يمكن للمالك فقط تعديل النموذج')
      }
      
      return await modelService.updateModel(id, input)
    },

    deleteModel: async (parent, { id }, context) => {
      if (!context.user || !await modelService.isOwner(context.user.id, id)) {
        throw new ForbiddenError('يمكن للمالك فقط حذف النموذج')
      }
      
      return await modelService.deleteModel(id)
    },

    // التعاون
    addCollaborator: async (parent, { input }, context) => {
      if (!context.user || !await projectService.canManageCollaborators(context.user.id, input.projectId)) {
        throw new ForbiddenError('ليس لديك صلاحية لإضافة متعاونين')
      }
      
      return await collaborationService.addCollaborator(input)
    },

    removeCollaborator: async (parent, { projectId, userId }, context) => {
      if (!context.user || !await projectService.canManageCollaborators(context.user.id, projectId)) {
        throw new ForbiddenError('ليس لديك صلاحية لإزالة متعاونين')
      }
      
      return await collaborationService.removeCollaborator(projectId, userId)
    },

    // إجراءات المشهد
    updateScene: async (parent, { projectId, sceneData }, context) => {
      if (!context.user || !await projectService.canEdit(context.user.id, projectId)) {
        throw new ForbiddenError('ليس لديك صلاحية لتعديل المشهد')
      }
      
      const result = await projectService.updateScene(projectId, sceneData)
      
      // تسجيل التغيير
      await projectService.logChange({
        projectId,
        userId: context.user.id,
        actionType: 'UPDATE_SCENE',
        newData: sceneData
      })
      
      return result
    },

    addObject: async (parent, { projectId, objectData }, context) => {
      if (!context.user || !await projectService.canEdit(context.user.id, projectId)) {
        throw new ForbiddenError('ليس لديك صلاحية لإضافة كائنات')
      }
      
      const result = await projectService.addObject(projectId, objectData)
      
      // تسجيل التغيير
      await projectService.logChange({
        projectId,
        userId: context.user.id,
        actionType: 'ADD_OBJECT',
        objectId: objectData.id,
        newData: objectData
      })
      
      return result
    },

    updateObject: async (parent, { projectId, objectId, updates }, context) => {
      if (!context.user || !await projectService.canEdit(context.user.id, projectId)) {
        throw new ForbiddenError('ليس لديك صلاحية لتعديل الكائنات')
      }
      
      // الحصول على البيانات القديمة
      const oldData = await projectService.getObjectData(projectId, objectId)
      
      const result = await projectService.updateObject(projectId, objectId, updates)
      
      // تسجيل التغيير
      await projectService.logChange({
        projectId,
        userId: context.user.id,
        actionType: 'UPDATE_OBJECT',
        objectId,
        oldData,
        newData: updates
      })
      
      return result
    },

    deleteObject: async (parent, { projectId, objectId }, context) => {
      if (!context.user || !await projectService.canEdit(context.user.id, projectId)) {
        throw new ForbiddenError('ليس لديك صلاحية لحذف الكائنات')
      }
      
      // الحصول على البيانات القديمة
      const oldData = await projectService.getObjectData(projectId, objectId)
      
      const result = await projectService.deleteObject(projectId, objectId)
      
      // تسجيل التغيير
      await projectService.logChange({
        projectId,
        userId: context.user.id,
        actionType: 'DELETE_OBJECT',
        objectId,
        oldData
      })
      
      return result
    }
  },

  // العلاقات
  Project: {
    owner: async (project) => {
      return await userService.getUserById(project.owner_id)
    },
    
    collaborators: async (project) => {
      return await collaborationService.getProjectCollaborators(project.id)
    }
  },

  Model: {
    owner: async (model) => {
      return await userService.getUserById(model.owner_id)
    }
  },

  Collaborator: {
    project: async (collaborator) => {
      return await projectService.getProjectById(collaborator.project_id)
    },
    
    user: async (collaborator) => {
      return await userService.getUserById(collaborator.user_id)
    }
  },

  CollaborationSession: {
    project: async (session) => {
      return await projectService.getProjectById(session.project_id)
    },
    
    host: async (session) => {
      return await userService.getUserById(session.host_id)
    },
    
    participants: async (session) => {
      return await collaborationService.getSessionParticipants(session.id)
    }
  },

  SessionParticipant: {
    session: async (participant) => {
      return await collaborationService.getSessionById(participant.session_id)
    },
    
    user: async (participant) => {
      return await userService.getUserById(participant.user_id)
    }
  }
}
