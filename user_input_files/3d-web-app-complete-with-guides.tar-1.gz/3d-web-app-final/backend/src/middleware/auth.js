import jwt from 'jsonwebtoken'
import { cacheUtils } from '../config/redis.js'
import { getUserById } from '../services/userService.js'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production'

export const authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '')
    
    if (!token) {
      req.user = null
      return next()
    }

    // التحقق من صحة التوكن
    const decoded = jwt.verify(token, JWT_SECRET)
    
    // التحقق من الجلسة في Redis
    const sessionData = await cacheUtils.getSession(token)
    if (!sessionData) {
      req.user = null
      return next()
    }

    // الحصول على بيانات المستخدم
    const user = await getUserById(decoded.userId)
    
    if (!user || !user.isActive) {
      await cacheUtils.deleteSession(token)
      req.user = null
      return next()
    }

    req.user = user
    req.token = token
    next()
  } catch (error) {
    console.error('❌ خطأ في المصادقة:', error)
    req.user = null
    next()
  }
}

export const requireAuth = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({
      error: 'يجب تسجيل الدخول للوصول إلى هذا المورد'
    })
  }
  next()
}

export const requireRole = (roles = []) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'يجب تسجيل الدخول للوصول إلى هذا المورد'
      })
    }

    if (roles.length > 0 && !roles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'ليس لديك الصلاحية للوصول إلى هذا المورد'
      })
    }

    next()
  }
}

// دالة لإنشاء JWT token
export const generateToken = (payload, expiresIn = '24h') => {
  return jwt.sign(payload, JWT_SECRET, { expiresIn })
}

// دالة للتحقق من صحة التوكن
export const verifyToken = (token) => {
  try {
    return jwt.verify(token, JWT_SECRET)
  } catch (error) {
    throw new Error('رمز المصادقة غير صالح')
  }
}

// middleware لتتبع النشاط
export const activityTracker = async (req, res, next) => {
  if (req.user) {
    // تحديث آخر نشاط للمستخدم
    await cacheUtils.set(
      `user_activity:${req.user.id}`,
      {
        lastActivity: new Date(),
        endpoint: req.originalUrl,
        method: req.method,
        ip: req.ip
      },
      300 // 5 دقائق
    )
  }
  next()
}
