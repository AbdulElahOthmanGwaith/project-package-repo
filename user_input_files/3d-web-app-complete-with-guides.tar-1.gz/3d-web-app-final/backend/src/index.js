import express from 'express'
import { ApolloServer } from 'apollo-server-express'
import cors from 'cors'
import helmet from 'helmet'
import compression from 'compression'
import { createServer } from 'http'
import { WebSocketServer } from 'ws'
import dotenv from 'dotenv'

import { typeDefs, resolvers } from './graphql/index.js'
import { authMiddleware } from './middleware/auth.js'
import { connectDB } from './config/database.js'
import { connectRedis } from './config/redis.js'
import routes from './routes/index.js'
import { setupWebSocket } from './services/websocket.js'

// تحميل متغيرات البيئة
dotenv.config()

const PORT = process.env.PORT || 4000
const NODE_ENV = process.env.NODE_ENV || 'development'

async function startServer() {
  try {
    // إنشاء تطبيق Express
    const app = express()
    
    // إعداد الأمان والضغط
    app.use(helmet({
      contentSecurityPolicy: NODE_ENV === 'production',
      crossOriginEmbedderPolicy: false
    }))
    app.use(compression())
    app.use(cors({
      origin: process.env.FRONTEND_URL || 'http://localhost:3000',
      credentials: true
    }))
    app.use(express.json({ limit: '50mb' }))
    app.use(express.urlencoded({ extended: true, limit: '50mb' }))

    // الاتصال بقواعد البيانات
    console.log('🔄 جاري الاتصال بقاعدة البيانات...')
    await connectDB()
    console.log('✅ تم الاتصال بقاعدة بيانات PostgreSQL')
    
    await connectRedis()
    console.log('✅ تم الاتصال بـ Redis')

    // إعداد Apollo Server لـ GraphQL
    const server = new ApolloServer({
      typeDefs,
      resolvers,
      context: ({ req, res }) => ({
        req,
        res,
        user: req.user || null
      }),
      introspection: NODE_ENV !== 'production',
      playground: NODE_ENV !== 'production'
    })

    await server.start()
    server.applyMiddleware({ 
      app, 
      path: '/graphql',
      cors: false // نستخدم cors من express
    })

    // تطبيق middleware للمصادقة
    app.use('/api', authMiddleware)

    // إعداد REST API routes
    app.use('/api', routes)

    // endpoint للتحقق من حالة الخادم
    app.get('/health', (req, res) => {
      res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || '1.0.0',
        environment: NODE_ENV
      })
    })

    // معالجة الأخطاء العامة
    app.use((error, req, res, next) => {
      console.error('❌ خطأ في الخادم:', error)
      res.status(500).json({
        error: NODE_ENV === 'production' 
          ? 'حدث خطأ في الخادم' 
          : error.message
      })
    })

    // إنشاء HTTP server
    const httpServer = createServer(app)

    // إعداد WebSocket server للتعاون في الوقت الفعلي
    const wsServer = new WebSocketServer({ server: httpServer })
    setupWebSocket(wsServer)

    // تشغيل الخادم
    httpServer.listen(PORT, () => {
      console.log(`🚀 خادم التطبيق يعمل على المنفذ ${PORT}`)
      console.log(`🔗 GraphQL Playground: http://localhost:${PORT}${server.graphqlPath}`)
      console.log(`🔗 REST API: http://localhost:${PORT}/api`)
      console.log(`📡 WebSocket: ws://localhost:${PORT}`)
    })

    // إيقاف الخادم بشكل نظيف
    process.on('SIGTERM', () => {
      console.log('🔄 جاري إيقاف الخادم...')
      httpServer.close(() => {
        console.log('✅ تم إيقاف الخادم بنجاح')
        process.exit(0)
      })
    })

    process.on('SIGINT', () => {
      console.log('🔄 تم إيقاف الخادم (Ctrl+C)')
      httpServer.close(() => {
        console.log('✅ تم إيقاف الخادم بنجاح')
        process.exit(0)
      })
    })

  } catch (error) {
    console.error('❌ فشل في تشغيل الخادم:', error)
    process.exit(1)
  }
}

// تشغيل الخادم
startServer().catch(console.error)
