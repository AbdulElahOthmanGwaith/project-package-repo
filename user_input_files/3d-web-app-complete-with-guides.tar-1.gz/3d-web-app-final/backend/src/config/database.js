import pkg from 'pg'
const { Pool } = pkg

let pool

export async function connectDB() {
  try {
    pool = new Pool({
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 5432,
      database: process.env.DB_NAME || '3d_web_app',
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASSWORD || 'password',
      max: 20, // الحد الأقصى للاتصالات
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    })

    // اختبار الاتصال
    await pool.query('SELECT NOW()')
    
    // إنشاء الجداول إذا لم تكن موجودة
    await createTables()
    
    console.log('✅ تم الاتصال بقاعدة البيانات PostgreSQL بنجاح')
  } catch (error) {
    console.error('❌ فشل الاتصال بقاعدة البيانات:', error)
    throw error
  }
}

export function getDB() {
  if (!pool) {
    throw new Error('قاعدة البيانات غير متصلة')
  }
  return pool
}

async function createTables() {
  const client = pool

  try {
    // إنشاء امتداد PostGIS
    await client.query(`
      CREATE EXTENSION IF NOT EXISTS postgis;
    `)

    // جدول المستخدمين
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(100),
        avatar_url TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        last_login TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `)

    // جدول المشاريع
    await client.query(`
      CREATE TABLE IF NOT EXISTS projects (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR(100) NOT NULL,
        description TEXT,
        owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
        is_public BOOLEAN DEFAULT FALSE,
        thumbnail_url TEXT,
        scene_data JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `)

    // جدول النماذج ثلاثية الأبعاد
    await client.query(`
      CREATE TABLE IF NOT EXISTS models (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR(100) NOT NULL,
        file_url TEXT NOT NULL,
        file_size BIGINT,
        file_type VARCHAR(50),
        thumbnail_url TEXT,
        bounding_box JSONB,
        metadata JSONB,
        owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
        is_public BOOLEAN DEFAULT FALSE,
        download_count INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `)

    // جدول مشاركة المشاريع
    await client.query(`
      CREATE TABLE IF NOT EXISTS project_collaborators (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        role VARCHAR(20) DEFAULT 'viewer', -- viewer, editor, admin
        permissions JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(project_id, user_id)
      );
    `)

    // جدول جلسات التعاون المباشر
    await client.query(`
      CREATE TABLE IF NOT EXISTS collaboration_sessions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
        host_id UUID REFERENCES users(id) ON DELETE CASCADE,
        session_name VARCHAR(100),
        is_active BOOLEAN DEFAULT TRUE,
        max_participants INTEGER DEFAULT 10,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ended_at TIMESTAMP
      );
    `)

    // جدول المشاركين في الجلسات
    await client.query(`
      CREATE TABLE IF NOT EXISTS session_participants (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        session_id UUID REFERENCES collaboration_sessions(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        cursor_position POINT,
        is_online BOOLEAN DEFAULT TRUE,
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        left_at TIMESTAMP,
        UNIQUE(session_id, user_id)
      );
    `)

    // جدول تاريخ التغييرات
    await client.query(`
      CREATE TABLE IF NOT EXISTS change_history (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        action_type VARCHAR(50) NOT NULL, -- create, update, delete, move, etc.
        object_id VARCHAR(100),
        old_data JSONB,
        new_data JSONB,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `)

    // إنشاء الفهارس للأداء
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
      CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
      CREATE INDEX IF NOT EXISTS idx_projects_owner ON projects(owner_id);
      CREATE INDEX IF NOT EXISTS idx_models_owner ON models(owner_id);
      CREATE INDEX IF NOT EXISTS idx_models_public ON models(is_public);
      CREATE INDEX IF NOT EXISTS idx_collaborators_project ON project_collaborators(project_id);
      CREATE INDEX IF NOT EXISTS idx_collaborators_user ON project_collaborators(user_id);
      CREATE INDEX IF NOT EXISTS idx_sessions_project ON collaboration_sessions(project_id);
      CREATE INDEX IF NOT EXISTS idx_participants_session ON session_participants(session_id);
      CREATE INDEX IF NOT EXISTS idx_history_project ON change_history(project_id);
    `)

    console.log('✅ تم إنشاء/تحديث هيكل قاعدة البيانات')
  } catch (error) {
    console.error('❌ فشل في إنشاء هيكل قاعدة البيانات:', error)
    throw error
  }
}

export async function closeDB() {
  if (pool) {
    await pool.end()
    console.log('🔌 تم قطع الاتصال بقاعدة البيانات')
  }
}
