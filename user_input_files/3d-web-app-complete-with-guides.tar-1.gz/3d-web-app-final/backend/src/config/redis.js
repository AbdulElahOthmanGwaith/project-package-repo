import { createClient } from 'redis'

let redisClient

export async function connectRedis() {
  try {
    redisClient = createClient({
      host: process.env.REDIS_HOST || 'localhost',
      port: process.env.REDIS_PORT || 6379,
      password: process.env.REDIS_PASSWORD || undefined,
      db: process.env.REDIS_DB || 0,
      retry_strategy: (options) => {
        if (options.error && options.error.code === 'ECONNREFUSED') {
          console.error('❌ الخادم Redis يرفض الاتصال')
        }
        if (options.total_retry_time > 1000 * 60 * 60) {
          console.error('❌ انتهت مهلة إعادة المحاولة للاتصال بـ Redis')
          return new Error('انتهت مهلة إعادة المحاولة')
        }
        if (options.attempt > 10) {
          console.error('❌ تجاوز عدد محاولات الاتصال بـ Redis')
          return undefined
        }
        return Math.min(options.attempt * 100, 3000)
      }
    })

    redisClient.on('error', (err) => {
      console.error('❌ خطأ Redis:', err)
    })

    redisClient.on('connect', () => {
      console.log('🔗 يتم الاتصال بـ Redis...')
    })

    redisClient.on('ready', () => {
      console.log('✅ Redis جاهز للاستخدام')
    })

    redisClient.on('reconnecting', () => {
      console.log('🔄 إعادة الاتصال بـ Redis...')
    })

    await redisClient.connect()
    
    // اختبار الاتصال
    await redisClient.ping()
    
    console.log('✅ تم الاتصال بـ Redis بنجاح')
  } catch (error) {
    console.error('❌ فشل الاتصال بـ Redis:', error)
    // Redis ليس ضرورياً للتشغيل الأساسي، لذا نستمر بدونه
    console.warn('⚠️ سيتم التشغيل بدون Redis (بدون تخزين مؤقت)')
  }
}

export function getRedis() {
  return redisClient
}

// دوال المساعدة للتخزين المؤقت
export const cacheUtils = {
  // تخزين البيانات
  async set(key, value, expiration = 3600) {
    if (!redisClient || !redisClient.isReady) return null
    try {
      const serialized = JSON.stringify(value)
      if (expiration) {
        await redisClient.setEx(key, expiration, serialized)
      } else {
        await redisClient.set(key, serialized)
      }
      return true
    } catch (error) {
      console.error('❌ فشل في تخزين البيانات في Redis:', error)
      return false
    }
  },

  // استرداد البيانات
  async get(key) {
    if (!redisClient || !redisClient.isReady) return null
    try {
      const value = await redisClient.get(key)
      return value ? JSON.parse(value) : null
    } catch (error) {
      console.error('❌ فشل في استرداد البيانات من Redis:', error)
      return null
    }
  },

  // حذف البيانات
  async del(key) {
    if (!redisClient || !redisClient.isReady) return false
    try {
      await redisClient.del(key)
      return true
    } catch (error) {
      console.error('❌ فشل في حذف البيانات من Redis:', error)
      return false
    }
  },

  // تخزين بيانات الجلسة
  async setSession(sessionId, userData, expiration = 24 * 60 * 60) { // 24 ساعة
    return await this.set(`session:${sessionId}`, userData, expiration)
  },

  // استرداد بيانات الجلسة
  async getSession(sessionId) {
    return await this.get(`session:${sessionId}`)
  },

  // حذف بيانات الجلسة
  async deleteSession(sessionId) {
    return await this.del(`session:${sessionId}`)
  },

  // تخزين بيانات المستخدمين النشطين
  async setUserOnline(userId, socketId) {
    if (!redisClient || !redisClient.isReady) return false
    try {
      await redisClient.hSet('online_users', userId, socketId)
      await redisClient.setEx(`user_activity:${userId}`, 300, Date.now()) // 5 دقائق
      return true
    } catch (error) {
      console.error('❌ فشل في تحديث حالة المستخدم:', error)
      return false
    }
  },

  // إزالة المستخدم من القائمة النشطة
  async setUserOffline(userId) {
    if (!redisClient || !redisClient.isReady) return false
    try {
      await redisClient.hDel('online_users', userId)
      await redisClient.del(`user_activity:${userId}`)
      return true
    } catch (error) {
      console.error('❌ فشل في تحديث حالة المستخدم:', error)
      return false
    }
  },

  // الحصول على المستخدمين النشطين
  async getOnlineUsers() {
    if (!redisClient || !redisClient.isReady) return []
    try {
      const users = await redisClient.hGetAll('online_users')
      return Object.keys(users)
    } catch (error) {
      console.error('❌ فشل في الحصول على المستخدمين النشطين:', error)
      return []
    }
  },

  // تخزين معلومات التعاون المباشر
  async setCollaborationData(projectId, data, expiration = 1800) { // 30 دقيقة
    return await this.set(`collaboration:${projectId}`, data, expiration)
  },

  // استرداد معلومات التعاون
  async getCollaborationData(projectId) {
    return await this.get(`collaboration:${projectId}`)
  }
}

export async function closeRedis() {
  if (redisClient) {
    await redisClient.quit()
    console.log('🔌 تم قطع الاتصال بـ Redis')
  }
}
