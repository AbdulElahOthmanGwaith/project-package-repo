import express from 'express'
import multer from 'multer'
import path from 'path'
import { requireAuth } from '../middleware/auth.js'
import * as modelService from '../services/modelService.js'

const router = express.Router()

// إعداد multer للتعامل مع رفع الملفات
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // إنشاء مجلد التخزين إذا لم يكن موجوداً
    const uploadPath = 'uploads/models'
    cb(null, uploadPath)
  },
  filename: (req, file, cb) => {
    // إنشاء اسم ملف فريد
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const fileExt = path.extname(file.originalname)
    cb(null, file.fieldname + '-' + uniqueSuffix + fileExt)
  }
})

// فلتر أنواع الملفات المسموحة
const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    '.gltf', '.glb', '.fbx', '.obj', '.3ds', '.dae', '.ply', '.stl',
    '.jpg', '.jpeg', '.png', '.gif', '.webp' // للصور المرفقة
  ]
  
  const fileExt = path.extname(file.originalname).toLowerCase()
  
  if (allowedTypes.includes(fileExt)) {
    cb(null, true)
  } else {
    cb(new Error(`نوع الملف ${fileExt} غير مدعوم`), false)
  }
}

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50 MB حد أقصى
    files: 5 // حد أقصى 5 ملفات
  }
})

// رفع نموذج ثلاثي الأبعاد
router.post('/model', requireAuth, upload.fields([
  { name: 'model', maxCount: 1 },
  { name: 'thumbnail', maxCount: 1 },
  { name: 'textures', maxCount: 10 }
]), async (req, res) => {
  try {
    const { name, description, isPublic = false, metadata } = req.body
    
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ error: 'اسم النموذج مطلوب' })
    }

    if (!req.files || !req.files.model) {
      return res.status(400).json({ error: 'ملف النموذج مطلوب' })
    }

    const modelFile = req.files.model[0]
    const thumbnailFile = req.files.thumbnail ? req.files.thumbnail[0] : null
    const textureFiles = req.files.textures || []

    // إنشاء URLs للملفات
    const baseUrl = `${req.protocol}://${req.get('host')}`
    const modelUrl = `${baseUrl}/uploads/models/${modelFile.filename}`
    const thumbnailUrl = thumbnailFile ? `${baseUrl}/uploads/models/${thumbnailFile.filename}` : null
    
    const textureUrls = textureFiles.map(file => ({
      name: file.originalname,
      url: `${baseUrl}/uploads/models/${file.filename}`,
      type: path.extname(file.originalname)
    }))

    // تحليل الملف للحصول على معلومات إضافية
    const fileInfo = {
      originalName: modelFile.originalname,
      size: modelFile.size,
      type: path.extname(modelFile.originalname),
      uploadDate: new Date()
    }

    // دمج معلومات الملف مع الميتاداتا
    const finalMetadata = {
      ...JSON.parse(metadata || '{}'),
      fileInfo,
      textures: textureUrls,
      uploadedBy: req.user.id
    }

    // إنشاء النموذج في قاعدة البيانات
    const model = await modelService.createModel({
      name: name.trim(),
      fileUrl: modelUrl,
      fileSize: modelFile.size,
      fileType: path.extname(modelFile.originalname),
      thumbnailUrl,
      metadata: finalMetadata,
      ownerId: req.user.id,
      isPublic: isPublic === 'true' || isPublic === true
    })

    res.status(201).json({
      message: 'تم رفع النموذج بنجاح',
      model: model
    })

  } catch (error) {
    console.error('❌ خطأ في رفع النموذج:', error)
    res.status(500).json({ error: error.message || 'فشل في رفع النموذج' })
  }
})

// رفع صورة مصغرة لنموذج موجود
router.post('/thumbnail/:modelId', requireAuth, upload.single('thumbnail'), async (req, res) => {
  try {
    // التحقق من ملكية النموذج
    if (!await modelService.isOwner(req.user.id, req.params.modelId)) {
      return res.status(403).json({ error: 'يمكن للمالك فقط تحديث الصورة المصغرة' })
    }

    if (!req.file) {
      return res.status(400).json({ error: 'ملف الصورة مطلوب' })
    }

    const baseUrl = `${req.protocol}://${req.get('host')}`
    const thumbnailUrl = `${baseUrl}/uploads/models/${req.file.filename}`

    // تحديث النموذج
    const updatedModel = await modelService.updateModel(req.params.modelId, {
      thumbnailUrl
    })

    res.json({
      message: 'تم تحديث الصورة المصغرة بنجاح',
      thumbnailUrl,
      model: updatedModel
    })

  } catch (error) {
    console.error('❌ خطأ في رفع الصورة المصغرة:', error)
    res.status(500).json({ error: error.message || 'فشل في رفع الصورة المصغرة' })
  }
})

// رفع صورة لملف الشخصي للمستخدم
router.post('/avatar', requireAuth, upload.single('avatar'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'ملف الصورة مطلوب' })
    }

    // التحقق من أن الملف صورة
    const imageTypes = ['.jpg', '.jpeg', '.png', '.gif', '.webp']
    const fileExt = path.extname(req.file.originalname).toLowerCase()
    
    if (!imageTypes.includes(fileExt)) {
      return res.status(400).json({ error: 'يجب أن يكون الملف صورة' })
    }

    const baseUrl = `${req.protocol}://${req.get('host')}`
    const avatarUrl = `${baseUrl}/uploads/models/${req.file.filename}`

    res.json({
      message: 'تم رفع صورة الملف الشخصي بنجاح',
      avatarUrl
    })

  } catch (error) {
    console.error('❌ خطأ في رفع صورة الملف الشخصي:', error)
    res.status(500).json({ error: error.message || 'فشل في رفع صورة الملف الشخصي' })
  }
})

// رفع مرفقات إضافية لمشروع
router.post('/project-assets/:projectId', requireAuth, upload.array('assets', 10), async (req, res) => {
  try {
    const { projectId } = req.params
    
    // التحقق من صلاحية رفع الملفات للمشروع
    // هذا سيتطلب استيراد projectService
    // if (!await projectService.canEdit(req.user.id, projectId)) {
    //   return res.status(403).json({ error: 'ليس لديك صلاحية لرفع ملفات لهذا المشروع' })
    // }

    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'يجب رفع ملف واحد على الأقل' })
    }

    const baseUrl = `${req.protocol}://${req.get('host')}`
    const uploadedAssets = req.files.map(file => ({
      originalName: file.originalname,
      filename: file.filename,
      url: `${baseUrl}/uploads/models/${file.filename}`,
      size: file.size,
      type: path.extname(file.originalname),
      uploadDate: new Date()
    }))

    res.json({
      message: `تم رفع ${uploadedAssets.length} ملف بنجاح`,
      assets: uploadedAssets
    })

  } catch (error) {
    console.error('❌ خطأ في رفع مرفقات المشروع:', error)
    res.status(500).json({ error: error.message || 'فشل في رفع مرفقات المشروع' })
  }
})

// الحصول على معلومات الرفع
router.get('/info', (req, res) => {
  res.json({
    maxFileSize: '50MB',
    allowedModelTypes: ['.gltf', '.glb', '.fbx', '.obj', '.3ds', '.dae', '.ply', '.stl'],
    allowedImageTypes: ['.jpg', '.jpeg', '.png', '.gif', '.webp'],
    maxFilesPerUpload: 10,
    supportedFeatures: [
      'Multiple file upload',
      'Thumbnail generation',
      'Metadata extraction',
      'File type validation',
      'Progress tracking'
    ]
  })
})

// معالج الأخطاء الخاص بـ multer
router.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ error: 'حجم الملف كبير جداً (الحد الأقصى 50MB)' })
    }
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({ error: 'عدد الملفات المرفوعة يتجاوز الحد المسموح' })
    }
    if (error.code === 'LIMIT_UNEXPECTED_FILE') {
      return res.status(400).json({ error: 'حقل الملف غير متوقع' })
    }
  }
  
  if (error.message) {
    return res.status(400).json({ error: error.message })
  }
  
  next(error)
})

export default router
