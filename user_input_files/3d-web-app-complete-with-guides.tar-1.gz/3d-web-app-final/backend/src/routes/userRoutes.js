import express from 'express'
import { requireAuth } from '../middleware/auth.js'
import * as userService from '../services/userService.js'

const router = express.Router()

// الحصول على الملف الشخصي للمستخدم الحالي
router.get('/me', requireAuth, async (req, res) => {
  try {
    const user = await userService.getUserById(req.user.id)
    res.json(user)
  } catch (error) {
    console.error('❌ خطأ في الحصول على بيانات المستخدم:', error)
    res.status(500).json({ error: 'فشل في الحصول على بيانات المستخدم' })
  }
})

// تحديث الملف الشخصي
router.put('/me', requireAuth, async (req, res) => {
  try {
    const { username, fullName, avatarUrl } = req.body
    const updatedUser = await userService.updateUser(req.user.id, {
      username,
      fullName,
      avatarUrl
    })
    res.json(updatedUser)
  } catch (error) {
    console.error('❌ خطأ في تحديث بيانات المستخدم:', error)
    res.status(400).json({ error: error.message })
  }
})

// تغيير كلمة المرور
router.put('/me/password', requireAuth, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body

    if (!oldPassword || !newPassword) {
      return res.status(400).json({ error: 'كلمة المرور القديمة والجديدة مطلوبتان' })
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' })
    }

    await userService.changePassword(req.user.id, oldPassword, newPassword)
    res.json({ message: 'تم تغيير كلمة المرور بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في تغيير كلمة المرور:', error)
    res.status(400).json({ error: error.message })
  }
})

// البحث عن المستخدمين
router.get('/search', requireAuth, async (req, res) => {
  try {
    const { q, limit } = req.query
    
    if (!q || q.trim().length < 2) {
      return res.status(400).json({ error: 'يجب أن يكون طول البحث حرفين على الأقل' })
    }

    const users = await userService.searchUsers(q.trim(), parseInt(limit) || 10)
    res.json(users)
  } catch (error) {
    console.error('❌ خطأ في البحث عن المستخدمين:', error)
    res.status(500).json({ error: 'فشل في البحث عن المستخدمين' })
  }
})

// الحصول على مستخدم محدد
router.get('/:id', async (req, res) => {
  try {
    const user = await userService.getUserById(req.params.id)
    if (!user) {
      return res.status(404).json({ error: 'المستخدم غير موجود' })
    }
    
    // إزالة المعلومات الحساسة للمستخدمين الآخرين
    if (!req.user || req.user.id !== user.id) {
      delete user.email
      delete user.lastLogin
    }
    
    res.json(user)
  } catch (error) {
    console.error('❌ خطأ في الحصول على المستخدم:', error)
    res.status(500).json({ error: 'فشل في الحصول على بيانات المستخدم' })
  }
})

// حذف الحساب
router.delete('/me', requireAuth, async (req, res) => {
  try {
    await userService.deleteUser(req.user.id)
    res.json({ message: 'تم حذف الحساب بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في حذف الحساب:', error)
    res.status(500).json({ error: 'فشل في حذف الحساب' })
  }
})

export default router
