import express from 'express'
import userRoutes from './userRoutes.js'
import projectRoutes from './projectRoutes.js'
import modelRoutes from './modelRoutes.js'
import uploadRoutes from './uploadRoutes.js'

const router = express.Router()

// معلومات API
router.get('/', (req, res) => {
  res.json({
    name: 'تطبيق الويب ثلاثي الأبعاد API',
    version: '1.0.0',
    description: 'API متقدم لإدارة النماذج والمشاريع ثلاثية الأبعاد',
    endpoints: {
      users: '/api/users',
      projects: '/api/projects', 
      models: '/api/models',
      upload: '/api/upload',
      graphql: '/graphql',
      websocket: 'ws://localhost:4000'
    },
    documentation: 'https://docs.example.com',
    timestamp: new Date().toISOString()
  })
})

// تطبيق المسارات
router.use('/users', userRoutes)
router.use('/projects', projectRoutes)
router.use('/models', modelRoutes)
router.use('/upload', uploadRoutes)

// معالج الأخطاء للمسارات غير الموجودة
router.use('*', (req, res) => {
  res.status(404).json({
    error: 'المسار غير موجود',
    message: 'تحقق من عنوان URL أو راجع الوثائق',
    availableEndpoints: ['/users', '/projects', '/models', '/upload']
  })
})

export default router
