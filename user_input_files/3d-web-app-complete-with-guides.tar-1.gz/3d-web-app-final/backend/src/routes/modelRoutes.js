import express from 'express'
import { requireAuth } from '../middleware/auth.js'
import * as modelService from '../services/modelService.js'

const router = express.Router()

// الحصول على جميع النماذج العامة
router.get('/public', async (req, res) => {
  try {
    const models = await modelService.getPublicModels()
    res.json(models)
  } catch (error) {
    console.error('❌ خطأ في الحصول على النماذج العامة:', error)
    res.status(500).json({ error: 'فشل في الحصول على النماذج العامة' })
  }
})

// الحصول على نماذج المستخدم الحالي
router.get('/my', requireAuth, async (req, res) => {
  try {
    const models = await modelService.getUserModels(req.user.id)
    res.json(models)
  } catch (error) {
    console.error('❌ خطأ في الحصول على نماذج المستخدم:', error)
    res.status(500).json({ error: 'فشل في الحصول على نماذج المستخدم' })
  }
})

// البحث في النماذج
router.get('/search', async (req, res) => {
  try {
    const { q, fileType, isPublic, ownerId, limit } = req.query
    
    const filters = {}
    if (fileType) filters.fileType = fileType
    if (typeof isPublic === 'string') filters.isPublic = isPublic === 'true'
    if (ownerId) filters.ownerId = ownerId
    if (limit) filters.limit = parseInt(limit)

    const models = await modelService.searchModels(q, filters)
    res.json(models)
  } catch (error) {
    console.error('❌ خطأ في البحث في النماذج:', error)
    res.status(500).json({ error: 'فشل في البحث في النماذج' })
  }
})

// الحصول على نموذج محدد
router.get('/:id', async (req, res) => {
  try {
    const model = await modelService.getModelById(req.params.id)
    if (!model) {
      return res.status(404).json({ error: 'النموذج غير موجود' })
    }

    // التحقق من صلاحية الوصول
    if (!model.isPublic && (!req.user || !await modelService.canAccess(req.user.id, req.params.id))) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لعرض هذا النموذج' })
    }

    res.json(model)
  } catch (error) {
    console.error('❌ خطأ في الحصول على النموذج:', error)
    res.status(500).json({ error: 'فشل في الحصول على النموذج' })
  }
})

// تحديث نموذج
router.put('/:id', requireAuth, async (req, res) => {
  try {
    // التحقق من أن المستخدم هو المالك
    if (!await modelService.isOwner(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'يمكن للمالك فقط تعديل النموذج' })
    }

    const { name, isPublic, metadata, thumbnailUrl } = req.body
    
    const updatedModel = await modelService.updateModel(req.params.id, {
      name: name?.trim(),
      isPublic,
      metadata,
      thumbnailUrl
    })

    res.json(updatedModel)
  } catch (error) {
    console.error('❌ خطأ في تحديث النموذج:', error)
    res.status(400).json({ error: error.message })
  }
})

// حذف نموذج
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    // التحقق من أن المستخدم هو المالك
    if (!await modelService.isOwner(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'يمكن للمالك فقط حذف النموذج' })
    }

    await modelService.deleteModel(req.params.id)
    res.json({ message: 'تم حذف النموذج بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في حذف النموذج:', error)
    res.status(500).json({ error: error.message })
  }
})

// تحميل النموذج (زيادة عدد التحميلات)
router.post('/:id/download', async (req, res) => {
  try {
    const model = await modelService.getModelById(req.params.id)
    if (!model) {
      return res.status(404).json({ error: 'النموذج غير موجود' })
    }

    // التحقق من صلاحية الوصول
    if (!model.isPublic && (!req.user || !await modelService.canAccess(req.user.id, req.params.id))) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لتحميل هذا النموذج' })
    }

    // زيادة عدد التحميلات
    await modelService.incrementDownloadCount(req.params.id)

    res.json({ 
      message: 'تم تسجيل التحميل',
      downloadUrl: model.fileUrl 
    })
  } catch (error) {
    console.error('❌ خطأ في تحميل النموذج:', error)
    res.status(500).json({ error: 'فشل في تحميل النموذج' })
  }
})

// تحديث التحليلات
router.put('/:id/analytics', requireAuth, async (req, res) => {
  try {
    // التحقق من أن المستخدم هو المالك
    if (!await modelService.isOwner(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'يمكن للمالك فقط تحديث التحليلات' })
    }

    const { boundingBox, triangleCount, vertexCount, textureCount } = req.body
    
    await modelService.updateModelAnalytics(req.params.id, {
      boundingBox,
      triangleCount,
      vertexCount,
      textureCount
    })

    res.json({ message: 'تم تحديث التحليلات بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في تحديث التحليلات:', error)
    res.status(500).json({ error: 'فشل في تحديث التحليلات' })
  }
})

export default router
