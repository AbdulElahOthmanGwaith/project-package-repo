import express from 'express'
import { requireAuth } from '../middleware/auth.js'
import * as projectService from '../services/projectService.js'

const router = express.Router()

// الحصول على جميع المشاريع العامة
router.get('/public', async (req, res) => {
  try {
    const projects = await projectService.getPublicProjects()
    res.json(projects)
  } catch (error) {
    console.error('❌ خطأ في الحصول على المشاريع العامة:', error)
    res.status(500).json({ error: 'فشل في الحصول على المشاريع العامة' })
  }
})

// الحصول على مشاريع المستخدم الحالي
router.get('/my', requireAuth, async (req, res) => {
  try {
    const projects = await projectService.getUserProjects(req.user.id)
    res.json(projects)
  } catch (error) {
    console.error('❌ خطأ في الحصول على مشاريع المستخدم:', error)
    res.status(500).json({ error: 'فشل في الحصول على مشاريع المستخدم' })
  }
})

// إنشاء مشروع جديد
router.post('/', requireAuth, async (req, res) => {
  try {
    const { name, description, isPublic, sceneData } = req.body

    if (!name || name.trim().length === 0) {
      return res.status(400).json({ error: 'اسم المشروع مطلوب' })
    }

    const project = await projectService.createProject({
      name: name.trim(),
      description: description?.trim(),
      ownerId: req.user.id,
      isPublic: !!isPublic,
      sceneData: sceneData || {}
    })

    res.status(201).json(project)
  } catch (error) {
    console.error('❌ خطأ في إنشاء المشروع:', error)
    res.status(400).json({ error: error.message })
  }
})

// الحصول على مشروع محدد
router.get('/:id', async (req, res) => {
  try {
    const project = await projectService.getProjectById(req.params.id)
    if (!project) {
      return res.status(404).json({ error: 'المشروع غير موجود' })
    }

    // التحقق من صلاحية الوصول
    if (!project.isPublic && (!req.user || !await projectService.hasAccess(req.user.id, req.params.id))) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لعرض هذا المشروع' })
    }

    res.json(project)
  } catch (error) {
    console.error('❌ خطأ في الحصول على المشروع:', error)
    res.status(500).json({ error: 'فشل في الحصول على المشروع' })
  }
})

// تحديث مشروع
router.put('/:id', requireAuth, async (req, res) => {
  try {
    // التحقق من صلاحية التحرير
    if (!await projectService.canEdit(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لتعديل هذا المشروع' })
    }

    const { name, description, isPublic, sceneData, thumbnailUrl } = req.body
    
    const updatedProject = await projectService.updateProject(req.params.id, {
      name: name?.trim(),
      description: description?.trim(),
      isPublic,
      sceneData,
      thumbnailUrl
    })

    // تسجيل التغيير
    await projectService.logChange({
      projectId: req.params.id,
      userId: req.user.id,
      actionType: 'UPDATE_PROJECT',
      newData: { name, description, isPublic, thumbnailUrl }
    })

    res.json(updatedProject)
  } catch (error) {
    console.error('❌ خطأ في تحديث المشروع:', error)
    res.status(400).json({ error: error.message })
  }
})

// حذف مشروع
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    // التحقق من أن المستخدم هو المالك
    if (!await projectService.isOwner(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'يمكن للمالك فقط حذف المشروع' })
    }

    await projectService.deleteProject(req.params.id)
    res.json({ message: 'تم حذف المشروع بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في حذف المشروع:', error)
    res.status(500).json({ error: error.message })
  }
})

// تحديث المشهد
router.put('/:id/scene', requireAuth, async (req, res) => {
  try {
    // التحقق من صلاحية التحرير
    if (!await projectService.canEdit(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لتعديل المشهد' })
    }

    const { sceneData } = req.body
    
    if (!sceneData) {
      return res.status(400).json({ error: 'بيانات المشهد مطلوبة' })
    }

    const updatedProject = await projectService.updateScene(req.params.id, sceneData)

    // تسجيل التغيير
    await projectService.logChange({
      projectId: req.params.id,
      userId: req.user.id,
      actionType: 'UPDATE_SCENE',
      newData: sceneData
    })

    res.json(updatedProject)
  } catch (error) {
    console.error('❌ خطأ في تحديث المشهد:', error)
    res.status(400).json({ error: error.message })
  }
})

// إضافة كائن إلى المشهد
router.post('/:id/objects', requireAuth, async (req, res) => {
  try {
    // التحقق من صلاحية التحرير
    if (!await projectService.canEdit(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لإضافة كائنات' })
    }

    const { objectData } = req.body
    
    if (!objectData || !objectData.id) {
      return res.status(400).json({ error: 'بيانات الكائن ومعرفه مطلوبان' })
    }

    await projectService.addObject(req.params.id, objectData)

    // تسجيل التغيير
    await projectService.logChange({
      projectId: req.params.id,
      userId: req.user.id,
      actionType: 'ADD_OBJECT',
      objectId: objectData.id,
      newData: objectData
    })

    res.json({ message: 'تم إضافة الكائن بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في إضافة الكائن:', error)
    res.status(400).json({ error: error.message })
  }
})

// تحديث كائن في المشهد
router.put('/:id/objects/:objectId', requireAuth, async (req, res) => {
  try {
    // التحقق من صلاحية التحرير
    if (!await projectService.canEdit(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لتعديل الكائنات' })
    }

    const { updates } = req.body
    
    if (!updates) {
      return res.status(400).json({ error: 'التحديثات مطلوبة' })
    }

    // الحصول على البيانات القديمة
    const oldData = await projectService.getObjectData(req.params.id, req.params.objectId)

    await projectService.updateObject(req.params.id, req.params.objectId, updates)

    // تسجيل التغيير
    await projectService.logChange({
      projectId: req.params.id,
      userId: req.user.id,
      actionType: 'UPDATE_OBJECT',
      objectId: req.params.objectId,
      oldData,
      newData: updates
    })

    res.json({ message: 'تم تحديث الكائن بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في تحديث الكائن:', error)
    res.status(400).json({ error: error.message })
  }
})

// حذف كائن من المشهد
router.delete('/:id/objects/:objectId', requireAuth, async (req, res) => {
  try {
    // التحقق من صلاحية التحرير
    if (!await projectService.canEdit(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لحذف الكائنات' })
    }

    // الحصول على البيانات القديمة
    const oldData = await projectService.getObjectData(req.params.id, req.params.objectId)

    await projectService.deleteObject(req.params.id, req.params.objectId)

    // تسجيل التغيير
    await projectService.logChange({
      projectId: req.params.id,
      userId: req.user.id,
      actionType: 'DELETE_OBJECT',
      objectId: req.params.objectId,
      oldData
    })

    res.json({ message: 'تم حذف الكائن بنجاح' })
  } catch (error) {
    console.error('❌ خطأ في حذف الكائن:', error)
    res.status(400).json({ error: error.message })
  }
})

// الحصول على تاريخ المشروع
router.get('/:id/history', requireAuth, async (req, res) => {
  try {
    // التحقق من صلاحية الوصول
    if (!await projectService.hasAccess(req.user.id, req.params.id)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لعرض تاريخ هذا المشروع' })
    }

    const { limit = 50, offset = 0 } = req.query
    const history = await projectService.getProjectHistory(
      req.params.id, 
      parseInt(limit), 
      parseInt(offset)
    )

    res.json(history)
  } catch (error) {
    console.error('❌ خطأ في الحصول على تاريخ المشروع:', error)
    res.status(500).json({ error: 'فشل في الحصول على تاريخ المشروع' })
  }
})

export default router
