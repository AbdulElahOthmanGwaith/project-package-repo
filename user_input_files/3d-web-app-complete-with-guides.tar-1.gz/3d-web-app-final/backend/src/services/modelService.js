import { getDB } from '../config/database.js'
import { cacheUtils } from '../config/redis.js'

export async function createModel(modelData) {
  const { name, fileUrl, fileSize, fileType, thumbnailUrl, boundingBox, metadata, ownerId, isPublic = false } = modelData
  const db = getDB()

  try {
    const result = await db.query(`
      INSERT INTO models (name, file_url, file_size, file_type, thumbnail_url, bounding_box, metadata, owner_id, is_public)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id, name, file_url, file_size, file_type, thumbnail_url, bounding_box, metadata, owner_id, is_public, download_count, created_at, updated_at
    `, [name, fileUrl, fileSize, fileType, thumbnailUrl, 
        boundingBox ? JSON.stringify(boundingBox) : null,
        metadata ? JSON.stringify(metadata) : null,
        ownerId, isPublic])

    const model = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      fileUrl: result.rows[0].file_url,
      fileSize: result.rows[0].file_size,
      fileType: result.rows[0].file_type,
      thumbnailUrl: result.rows[0].thumbnail_url,
      boundingBox: result.rows[0].bounding_box,
      metadata: result.rows[0].metadata,
      ownerId: result.rows[0].owner_id,
      isPublic: result.rows[0].is_public,
      downloadCount: result.rows[0].download_count,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at
    }

    // حفظ في التخزين المؤقت
    await cacheUtils.set(`model:${model.id}`, model, 1800)

    console.log(`✅ تم إنشاء نموذج جديد: ${name}`)
    return model
  } catch (error) {
    console.error('❌ خطأ في إنشاء النموذج:', error)
    throw new Error(error.message || 'فشل في إنشاء النموذج')
  }
}

export async function getModelById(modelId) {
  const db = getDB()

  try {
    // محاولة الحصول من التخزين المؤقت أولاً
    const cachedModel = await cacheUtils.get(`model:${modelId}`)
    if (cachedModel) {
      return cachedModel
    }

    const result = await db.query(`
      SELECT id, name, file_url, file_size, file_type, thumbnail_url, bounding_box, metadata, owner_id, is_public, download_count, created_at, updated_at
      FROM models 
      WHERE id = $1
    `, [modelId])

    if (result.rows.length === 0) {
      return null
    }

    const model = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      fileUrl: result.rows[0].file_url,
      fileSize: result.rows[0].file_size,
      fileType: result.rows[0].file_type,
      thumbnailUrl: result.rows[0].thumbnail_url,
      boundingBox: result.rows[0].bounding_box,
      metadata: result.rows[0].metadata,
      ownerId: result.rows[0].owner_id,
      isPublic: result.rows[0].is_public,
      downloadCount: result.rows[0].download_count,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at
    }

    // حفظ في التخزين المؤقت
    await cacheUtils.set(`model:${modelId}`, model, 1800)

    return model
  } catch (error) {
    console.error('❌ خطأ في الحصول على النموذج:', error)
    throw new Error('فشل في الحصول على النموذج')
  }
}

export async function getAllModels() {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, name, file_url, file_size, file_type, thumbnail_url, owner_id, is_public, download_count, created_at, updated_at
      FROM models 
      ORDER BY download_count DESC, updated_at DESC
      LIMIT 100
    `)

    return result.rows.map(model => ({
      id: model.id,
      name: model.name,
      fileUrl: model.file_url,
      fileSize: model.file_size,
      fileType: model.file_type,
      thumbnailUrl: model.thumbnail_url,
      ownerId: model.owner_id,
      isPublic: model.is_public,
      downloadCount: model.download_count,
      createdAt: model.created_at,
      updatedAt: model.updated_at
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على قائمة النماذج:', error)
    throw new Error('فشل في الحصول على قائمة النماذج')
  }
}

export async function getUserModels(userId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, name, file_url, file_size, file_type, thumbnail_url, owner_id, is_public, download_count, created_at, updated_at
      FROM models 
      WHERE owner_id = $1
      ORDER BY updated_at DESC
    `, [userId])

    return result.rows.map(model => ({
      id: model.id,
      name: model.name,
      fileUrl: model.file_url,
      fileSize: model.file_size,
      fileType: model.file_type,
      thumbnailUrl: model.thumbnail_url,
      ownerId: model.owner_id,
      isPublic: model.is_public,
      downloadCount: model.download_count,
      createdAt: model.created_at,
      updatedAt: model.updated_at
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على نماذج المستخدم:', error)
    throw new Error('فشل في الحصول على نماذج المستخدم')
  }
}

export async function getPublicModels() {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, name, file_url, file_size, file_type, thumbnail_url, owner_id, is_public, download_count, created_at, updated_at
      FROM models 
      WHERE is_public = true
      ORDER BY download_count DESC, updated_at DESC
      LIMIT 50
    `)

    return result.rows.map(model => ({
      id: model.id,
      name: model.name,
      fileUrl: model.file_url,
      fileSize: model.file_size,
      fileType: model.file_type,
      thumbnailUrl: model.thumbnail_url,
      ownerId: model.owner_id,
      isPublic: model.is_public,
      downloadCount: model.download_count,
      createdAt: model.created_at,
      updatedAt: model.updated_at
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على النماذج العامة:', error)
    throw new Error('فشل في الحصول على النماذج العامة')
  }
}

export async function updateModel(modelId, updateData) {
  const db = getDB()

  try {
    const { name, isPublic, metadata, thumbnailUrl } = updateData
    
    const result = await db.query(`
      UPDATE models 
      SET name = COALESCE($2, name),
          is_public = COALESCE($3, is_public),
          metadata = COALESCE($4, metadata),
          thumbnail_url = COALESCE($5, thumbnail_url),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING id, name, file_url, file_size, file_type, thumbnail_url, metadata, owner_id, is_public, download_count, updated_at
    `, [modelId, name, isPublic, 
        metadata ? JSON.stringify(metadata) : null, thumbnailUrl])

    if (result.rows.length === 0) {
      throw new Error('النموذج غير موجود')
    }

    const model = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      fileUrl: result.rows[0].file_url,
      fileSize: result.rows[0].file_size,
      fileType: result.rows[0].file_type,
      thumbnailUrl: result.rows[0].thumbnail_url,
      metadata: result.rows[0].metadata,
      ownerId: result.rows[0].owner_id,
      isPublic: result.rows[0].is_public,
      downloadCount: result.rows[0].download_count,
      updatedAt: result.rows[0].updated_at
    }

    // تحديث التخزين المؤقت
    await cacheUtils.set(`model:${modelId}`, model, 1800)

    return model
  } catch (error) {
    console.error('❌ خطأ في تحديث النموذج:', error)
    throw new Error(error.message || 'فشل في تحديث النموذج')
  }
}

export async function deleteModel(modelId) {
  const db = getDB()

  try {
    const result = await db.query('DELETE FROM models WHERE id = $1 RETURNING id', [modelId])
    
    if (result.rows.length === 0) {
      throw new Error('النموذج غير موجود')
    }

    // حذف من التخزين المؤقت
    await cacheUtils.del(`model:${modelId}`)

    console.log(`✅ تم حذف النموذج: ${modelId}`)
    return true
  } catch (error) {
    console.error('❌ خطأ في حذف النموذج:', error)
    throw new Error(error.message || 'فشل في حذف النموذج')
  }
}

export async function incrementDownloadCount(modelId) {
  const db = getDB()

  try {
    await db.query(
      'UPDATE models SET download_count = download_count + 1 WHERE id = $1',
      [modelId]
    )
    
    // حذف من التخزين المؤقت لإجبار التحديث
    await cacheUtils.del(`model:${modelId}`)
    
    console.log(`📥 تم تحديث عدد التحميلات للنموذج: ${modelId}`)
  } catch (error) {
    console.error('❌ خطأ في تحديث عدد التحميلات:', error)
  }
}

// التحقق من الصلاحيات
export async function isOwner(userId, modelId) {
  const db = getDB()

  try {
    const result = await db.query(
      'SELECT id FROM models WHERE id = $1 AND owner_id = $2',
      [modelId, userId]
    )

    return result.rows.length > 0
  } catch (error) {
    console.error('❌ خطأ في التحقق من ملكية النموذج:', error)
    return false
  }
}

export async function canAccess(userId, modelId) {
  const db = getDB()

  try {
    const result = await db.query(
      'SELECT id FROM models WHERE id = $1 AND (is_public = true OR owner_id = $2)',
      [modelId, userId]
    )

    return result.rows.length > 0
  } catch (error) {
    console.error('❌ خطأ في التحقق من صلاحية الوصول للنموذج:', error)
    return false
  }
}

// البحث في النماذج
export async function searchModels(query, filters = {}) {
  const db = getDB()
  
  try {
    const { fileType, isPublic, ownerId, limit = 50 } = filters
    
    let whereClause = 'WHERE 1=1'
    const queryParams = []
    let paramIndex = 1

    // البحث في النص
    if (query && query.trim().length > 0) {
      whereClause += ` AND (name ILIKE $${paramIndex} OR metadata::text ILIKE $${paramIndex})`
      queryParams.push(`%${query.trim()}%`)
      paramIndex++
    }

    // فلتر نوع الملف
    if (fileType) {
      whereClause += ` AND file_type = $${paramIndex}`
      queryParams.push(fileType)
      paramIndex++
    }

    // فلتر العمومية
    if (typeof isPublic === 'boolean') {
      whereClause += ` AND is_public = $${paramIndex}`
      queryParams.push(isPublic)
      paramIndex++
    }

    // فلتر المالك
    if (ownerId) {
      whereClause += ` AND owner_id = $${paramIndex}`
      queryParams.push(ownerId)
      paramIndex++
    }

    const result = await db.query(`
      SELECT id, name, file_url, file_size, file_type, thumbnail_url, owner_id, is_public, download_count, created_at, updated_at
      FROM models 
      ${whereClause}
      ORDER BY download_count DESC, updated_at DESC
      LIMIT $${paramIndex}
    `, [...queryParams, limit])

    return result.rows.map(model => ({
      id: model.id,
      name: model.name,
      fileUrl: model.file_url,
      fileSize: model.file_size,
      fileType: model.file_type,
      thumbnailUrl: model.thumbnail_url,
      ownerId: model.owner_id,
      isPublic: model.is_public,
      downloadCount: model.download_count,
      createdAt: model.created_at,
      updatedAt: model.updated_at
    }))
  } catch (error) {
    console.error('❌ خطأ في البحث في النماذج:', error)
    throw new Error('فشل في البحث في النماذج')
  }
}

// تحديث بيانات النموذج التحليلية
export async function updateModelAnalytics(modelId, analyticsData) {
  const { boundingBox, triangleCount, vertexCount, textureCount } = analyticsData
  
  try {
    const metadata = {
      analytics: {
        triangleCount,
        vertexCount,
        textureCount,
        analyzedAt: new Date()
      }
    }

    await updateModel(modelId, {
      boundingBox,
      metadata
    })

    console.log(`📊 تم تحديث التحليلات للنموذج: ${modelId}`)
  } catch (error) {
    console.error('❌ خطأ في تحديث تحليلات النموذج:', error)
  }
}
