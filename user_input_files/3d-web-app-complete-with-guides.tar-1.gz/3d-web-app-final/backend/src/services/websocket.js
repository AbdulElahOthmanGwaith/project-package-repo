import { WebSocketServer } from 'ws'
import { verifyToken } from '../middleware/auth.js'
import { cacheUtils } from '../config/redis.js'
import { getUserById } from './userService.js'
import { hasAccess } from './projectService.js'

const connections = new Map()
const projectRooms = new Map()

export function setupWebSocket(wss) {
  console.log('🔌 إعداد خادم WebSocket للتعاون المباشر')

  wss.on('connection', async (ws, request) => {
    console.log('🔗 اتصال WebSocket جديد')
    
    ws.isAlive = true
    ws.projectId = null
    ws.userId = null

    // التعامل مع رسائل ping/pong للحفاظ على الاتصال
    ws.on('pong', () => {
      ws.isAlive = true
    })

    // معالجة الرسائل
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString())
        await handleMessage(ws, message)
      } catch (error) {
        console.error('❌ خطأ في معالجة رسالة WebSocket:', error)
        sendError(ws, 'خطأ في تنسيق الرسالة')
      }
    })

    // عند إغلاق الاتصال
    ws.on('close', () => {
      handleDisconnection(ws)
    })

    // التعامل مع الأخطاء
    ws.on('error', (error) => {
      console.error('❌ خطأ WebSocket:', error)
      handleDisconnection(ws)
    })
  })

  // فحص دوري للاتصالات المنقطعة
  setInterval(() => {
    wss.clients.forEach((ws) => {
      if (!ws.isAlive) {
        console.log('🔌 إزالة اتصال منقطع')
        return ws.terminate()
      }
      
      ws.isAlive = false
      ws.ping()
    })
  }, 30000) // كل 30 ثانية

  return wss
}

async function handleMessage(ws, message) {
  const { type, payload } = message

  switch (type) {
    case 'AUTH':
      await handleAuth(ws, payload)
      break

    case 'JOIN_PROJECT':
      await handleJoinProject(ws, payload)
      break

    case 'LEAVE_PROJECT':
      handleLeaveProject(ws)
      break

    case 'CURSOR_UPDATE':
      handleCursorUpdate(ws, payload)
      break

    case 'SCENE_UPDATE':
      await handleSceneUpdate(ws, payload)
      break

    case 'OBJECT_UPDATE':
      handleObjectUpdate(ws, payload)
      break

    case 'CHAT_MESSAGE':
      handleChatMessage(ws, payload)
      break

    default:
      sendError(ws, `نوع رسالة غير معروف: ${type}`)
  }
}

async function handleAuth(ws, payload) {
  try {
    const { token } = payload

    if (!token) {
      return sendError(ws, 'مطلوب رمز المصادقة')
    }

    // التحقق من صحة التوكن
    const decoded = verifyToken(token)
    const user = await getUserById(decoded.userId)

    if (!user || !user.isActive) {
      return sendError(ws, 'رمز المصادقة غير صالح')
    }

    ws.userId = user.id
    ws.user = user
    connections.set(ws.userId, ws)

    // تحديث حالة المستخدم في Redis
    await cacheUtils.setUserOnline(user.id, ws.id)

    sendSuccess(ws, 'AUTH_SUCCESS', { user })
    console.log(`✅ تم تسجيل دخول المستخدم: ${user.username}`)

  } catch (error) {
    console.error('❌ خطأ في المصادقة:', error)
    sendError(ws, 'فشل في المصادقة')
  }
}

async function handleJoinProject(ws, payload) {
  try {
    if (!ws.userId) {
      return sendError(ws, 'يجب المصادقة أولاً')
    }

    const { projectId } = payload

    if (!projectId) {
      return sendError(ws, 'معرف المشروع مطلوب')
    }

    // التحقق من صلاحية الوصول
    const hasProjectAccess = await hasAccess(ws.userId, projectId)
    if (!hasProjectAccess) {
      return sendError(ws, 'ليس لديك صلاحية للوصول إلى هذا المشروع')
    }

    // مغادرة المشروع السابق إن وجد
    if (ws.projectId) {
      handleLeaveProject(ws)
    }

    // الانضمام إلى المشروع الجديد
    ws.projectId = projectId

    if (!projectRooms.has(projectId)) {
      projectRooms.set(projectId, new Set())
    }
    projectRooms.get(projectId).add(ws)

    // إشعار المستخدمين الآخرين في المشروع
    broadcastToProject(projectId, {
      type: 'USER_JOINED',
      payload: {
        userId: ws.userId,
        user: ws.user,
        timestamp: new Date()
      }
    }, ws.userId)

    // إرسال قائمة المستخدمين النشطين في المشروع
    const activeUsers = getProjectActiveUsers(projectId)
    sendSuccess(ws, 'PROJECT_JOINED', { projectId, activeUsers })

    console.log(`🏠 المستخدم ${ws.user.username} انضم إلى المشروع ${projectId}`)

  } catch (error) {
    console.error('❌ خطأ في الانضمام إلى المشروع:', error)
    sendError(ws, 'فشل في الانضمام إلى المشروع')
  }
}

function handleLeaveProject(ws) {
  if (ws.projectId && projectRooms.has(ws.projectId)) {
    const room = projectRooms.get(ws.projectId)
    room.delete(ws)

    // إشعار المستخدمين الآخرين
    broadcastToProject(ws.projectId, {
      type: 'USER_LEFT',
      payload: {
        userId: ws.userId,
        timestamp: new Date()
      }
    }, ws.userId)

    // حذف الغرفة إذا كانت فارغة
    if (room.size === 0) {
      projectRooms.delete(ws.projectId)
    }

    console.log(`🚪 المستخدم ${ws.user?.username} غادر المشروع ${ws.projectId}`)
    ws.projectId = null
  }
}

function handleCursorUpdate(ws, payload) {
  if (!ws.projectId || !ws.userId) {
    return sendError(ws, 'يجب الانضمام إلى مشروع أولاً')
  }

  const { position, target } = payload

  // بث موقع المؤشر للمستخدمين الآخرين
  broadcastToProject(ws.projectId, {
    type: 'CURSOR_MOVED',
    payload: {
      userId: ws.userId,
      position,
      target,
      timestamp: new Date()
    }
  }, ws.userId)
}

async function handleSceneUpdate(ws, payload) {
  if (!ws.projectId || !ws.userId) {
    return sendError(ws, 'يجب الانضمام إلى مشروع أولاً')
  }

  try {
    // حفظ تحديثات المشهد في Redis للتزامن
    await cacheUtils.setCollaborationData(ws.projectId, {
      lastUpdate: new Date(),
      updatedBy: ws.userId,
      sceneData: payload.sceneData
    })

    // بث التحديثات للمستخدمين الآخرين
    broadcastToProject(ws.projectId, {
      type: 'SCENE_UPDATED',
      payload: {
        userId: ws.userId,
        sceneData: payload.sceneData,
        timestamp: new Date()
      }
    }, ws.userId)

    console.log(`🎬 تم تحديث المشهد في المشروع ${ws.projectId} بواسطة ${ws.user.username}`)

  } catch (error) {
    console.error('❌ خطأ في تحديث المشهد:', error)
    sendError(ws, 'فشل في تحديث المشهد')
  }
}

function handleObjectUpdate(ws, payload) {
  if (!ws.projectId || !ws.userId) {
    return sendError(ws, 'يجب الانضمام إلى مشروع أولاً')
  }

  const { objectId, action, data } = payload

  // بث تحديثات الكائن للمستخدمين الآخرين
  broadcastToProject(ws.projectId, {
    type: 'OBJECT_UPDATED',
    payload: {
      userId: ws.userId,
      objectId,
      action, // add, update, delete, move, etc.
      data,
      timestamp: new Date()
    }
  }, ws.userId)
}

function handleChatMessage(ws, payload) {
  if (!ws.projectId || !ws.userId) {
    return sendError(ws, 'يجب الانضمام إلى مشروع أولاً')
  }

  const { message } = payload

  if (!message || message.trim().length === 0) {
    return sendError(ws, 'الرسالة لا يمكن أن تكون فارغة')
  }

  // بث الرسالة للمستخدمين الآخرين في المشروع
  broadcastToProject(ws.projectId, {
    type: 'CHAT_MESSAGE',
    payload: {
      userId: ws.userId,
      user: ws.user,
      message: message.trim(),
      timestamp: new Date()
    }
  })
}

function handleDisconnection(ws) {
  if (ws.userId) {
    // إزالة من الاتصالات النشطة
    connections.delete(ws.userId)
    
    // تحديث حالة المستخدم في Redis
    cacheUtils.setUserOffline(ws.userId).catch(console.error)
    
    // مغادرة المشروع
    handleLeaveProject(ws)
    
    console.log(`🔌 انقطع اتصال المستخدم: ${ws.user?.username}`)
  }
}

// دوال المساعدة
function broadcastToProject(projectId, message, excludeUserId = null) {
  const room = projectRooms.get(projectId)
  if (!room) return

  const messageStr = JSON.stringify(message)
  
  room.forEach(client => {
    if (client.readyState === 1 && client.userId !== excludeUserId) { // WebSocket.OPEN
      try {
        client.send(messageStr)
      } catch (error) {
        console.error('❌ خطأ في إرسال رسالة WebSocket:', error)
      }
    }
  })
}

function getProjectActiveUsers(projectId) {
  const room = projectRooms.get(projectId)
  if (!room) return []

  return Array.from(room)
    .filter(client => client.readyState === 1)
    .map(client => ({
      id: client.userId,
      username: client.user?.username,
      fullName: client.user?.fullName,
      avatarUrl: client.user?.avatarUrl
    }))
}

function sendSuccess(ws, type, payload = {}) {
  if (ws.readyState === 1) { // WebSocket.OPEN
    ws.send(JSON.stringify({
      type: 'SUCCESS',
      success_type: type,
      payload
    }))
  }
}

function sendError(ws, message) {
  if (ws.readyState === 1) { // WebSocket.OPEN
    ws.send(JSON.stringify({
      type: 'ERROR',
      message
    }))
  }
}

// دوال للوصول من خارج الملف
export function broadcastToUser(userId, message) {
  const ws = connections.get(userId)
  if (ws && ws.readyState === 1) {
    ws.send(JSON.stringify(message))
    return true
  }
  return false
}

export function getActiveUsers() {
  return Array.from(connections.keys())
}

export function getProjectUsers(projectId) {
  return getProjectActiveUsers(projectId)
}

export { broadcastToProject }
