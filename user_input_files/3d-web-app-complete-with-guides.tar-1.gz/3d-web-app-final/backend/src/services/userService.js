import bcrypt from 'bcryptjs'
import { v4 as uuidv4 } from 'uuid'
import { getDB } from '../config/database.js'
import { generateToken } from '../middleware/auth.js'
import { cacheUtils } from '../config/redis.js'

const SALT_ROUNDS = 12

export async function register(userData) {
  const { username, email, password, fullName } = userData
  const db = getDB()

  try {
    // التحقق من عدم وجود مستخدم بنفس البريد الإلكتروني أو اسم المستخدم
    const existingUser = await db.query(
      'SELECT id FROM users WHERE email = $1 OR username = $2',
      [email, username]
    )

    if (existingUser.rows.length > 0) {
      throw new Error('البريد الإلكتروني أو اسم المستخدم موجود بالفعل')
    }

    // تشفير كلمة المرور
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS)

    // إنشاء المستخدم الجديد
    const result = await db.query(`
      INSERT INTO users (username, email, password_hash, full_name)
      VALUES ($1, $2, $3, $4)
      RETURNING id, username, email, full_name, created_at
    `, [username, email, passwordHash, fullName])

    const user = result.rows[0]

    // إنشاء JWT token
    const token = generateToken({ userId: user.id })

    return {
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.full_name,
        createdAt: user.created_at
      }
    }
  } catch (error) {
    console.error('❌ خطأ في تسجيل المستخدم:', error)
    throw new Error(error.message || 'فشل في تسجيل المستخدم')
  }
}

export async function login(loginData) {
  const { email, password } = loginData
  const db = getDB()

  try {
    // البحث عن المستخدم
    const result = await db.query(`
      SELECT id, username, email, password_hash, full_name, avatar_url, is_active
      FROM users 
      WHERE email = $1
    `, [email])

    if (result.rows.length === 0) {
      throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة')
    }

    const user = result.rows[0]

    if (!user.is_active) {
      throw new Error('الحساب معطل، يرجى التواصل مع الدعم الفني')
    }

    // التحقق من كلمة المرور
    const isPasswordValid = await bcrypt.compare(password, user.password_hash)
    if (!isPasswordValid) {
      throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة')
    }

    // تحديث آخر تسجيل دخول
    await db.query(
      'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1',
      [user.id]
    )

    // إنشاء JWT token
    const token = generateToken({ userId: user.id })

    // تخزين بيانات الجلسة في Redis
    await cacheUtils.setSession(token, {
      userId: user.id,
      loginTime: new Date(),
      loginIP: null // سيتم إضافة IP address لاحقاً
    })

    return {
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.full_name,
        avatarUrl: user.avatar_url,
        isActive: user.is_active
      }
    }
  } catch (error) {
    console.error('❌ خطأ في تسجيل الدخول:', error)
    throw new Error(error.message || 'فشل في تسجيل الدخول')
  }
}

export async function getUserById(userId) {
  const db = getDB()

  try {
    // محاولة الحصول على البيانات من التخزين المؤقت أولاً
    const cachedUser = await cacheUtils.get(`user:${userId}`)
    if (cachedUser) {
      return cachedUser
    }

    const result = await db.query(`
      SELECT id, username, email, full_name, avatar_url, is_active, last_login, created_at, updated_at
      FROM users 
      WHERE id = $1
    `, [userId])

    if (result.rows.length === 0) {
      return null
    }

    const user = {
      id: result.rows[0].id,
      username: result.rows[0].username,
      email: result.rows[0].email,
      fullName: result.rows[0].full_name,
      avatarUrl: result.rows[0].avatar_url,
      isActive: result.rows[0].is_active,
      lastLogin: result.rows[0].last_login,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at
    }

    // حفظ في التخزين المؤقت لمدة 15 دقيقة
    await cacheUtils.set(`user:${userId}`, user, 900)

    return user
  } catch (error) {
    console.error('❌ خطأ في الحصول على بيانات المستخدم:', error)
    throw new Error('فشل في الحصول على بيانات المستخدم')
  }
}

export async function getAllUsers() {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, username, email, full_name, avatar_url, is_active, last_login, created_at
      FROM users 
      WHERE is_active = true
      ORDER BY created_at DESC
    `)

    return result.rows.map(user => ({
      id: user.id,
      username: user.username,
      email: user.email,
      fullName: user.full_name,
      avatarUrl: user.avatar_url,
      isActive: user.is_active,
      lastLogin: user.last_login,
      createdAt: user.created_at
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على قائمة المستخدمين:', error)
    throw new Error('فشل في الحصول على قائمة المستخدمين')
  }
}

export async function updateUser(userId, updateData) {
  const db = getDB()

  try {
    const { username, fullName, avatarUrl } = updateData
    
    const result = await db.query(`
      UPDATE users 
      SET username = COALESCE($2, username),
          full_name = COALESCE($3, full_name),
          avatar_url = COALESCE($4, avatar_url),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING id, username, email, full_name, avatar_url, is_active, updated_at
    `, [userId, username, fullName, avatarUrl])

    if (result.rows.length === 0) {
      throw new Error('المستخدم غير موجود')
    }

    const user = {
      id: result.rows[0].id,
      username: result.rows[0].username,
      email: result.rows[0].email,
      fullName: result.rows[0].full_name,
      avatarUrl: result.rows[0].avatar_url,
      isActive: result.rows[0].is_active,
      updatedAt: result.rows[0].updated_at
    }

    // تحديث التخزين المؤقت
    await cacheUtils.set(`user:${userId}`, user, 900)

    return user
  } catch (error) {
    console.error('❌ خطأ في تحديث بيانات المستخدم:', error)
    throw new Error(error.message || 'فشل في تحديث بيانات المستخدم')
  }
}

export async function changePassword(userId, oldPassword, newPassword) {
  const db = getDB()

  try {
    // التحقق من كلمة المرور الحالية
    const result = await db.query(
      'SELECT password_hash FROM users WHERE id = $1',
      [userId]
    )

    if (result.rows.length === 0) {
      throw new Error('المستخدم غير موجود')
    }

    const isOldPasswordValid = await bcrypt.compare(oldPassword, result.rows[0].password_hash)
    if (!isOldPasswordValid) {
      throw new Error('كلمة المرور الحالية غير صحيحة')
    }

    // تشفير كلمة المرور الجديدة
    const newPasswordHash = await bcrypt.hash(newPassword, SALT_ROUNDS)

    // تحديث كلمة المرور
    await db.query(
      'UPDATE users SET password_hash = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $1',
      [userId, newPasswordHash]
    )

    return true
  } catch (error) {
    console.error('❌ خطأ في تغيير كلمة المرور:', error)
    throw new Error(error.message || 'فشل في تغيير كلمة المرور')
  }
}

export async function deleteUser(userId) {
  const db = getDB()

  try {
    // تعطيل الحساب بدلاً من حذفه (soft delete)
    await db.query(
      'UPDATE users SET is_active = false, updated_at = CURRENT_TIMESTAMP WHERE id = $1',
      [userId]
    )

    // حذف من التخزين المؤقت
    await cacheUtils.del(`user:${userId}`)

    return true
  } catch (error) {
    console.error('❌ خطأ في حذف المستخدم:', error)
    throw new Error('فشل في حذف المستخدم')
  }
}

// دالة للبحث عن المستخدمين
export async function searchUsers(query, limit = 10) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, username, email, full_name, avatar_url
      FROM users 
      WHERE is_active = true 
        AND (username ILIKE $1 OR full_name ILIKE $1 OR email ILIKE $1)
      ORDER BY username
      LIMIT $2
    `, [`%${query}%`, limit])

    return result.rows.map(user => ({
      id: user.id,
      username: user.username,
      email: user.email,
      fullName: user.full_name,
      avatarUrl: user.avatar_url
    }))
  } catch (error) {
    console.error('❌ خطأ في البحث عن المستخدمين:', error)
    throw new Error('فشل في البحث عن المستخدمين')
  }
}
