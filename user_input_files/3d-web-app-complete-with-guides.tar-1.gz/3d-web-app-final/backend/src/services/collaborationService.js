import { getDB } from '../config/database.js'
import { cacheUtils } from '../config/redis.js'

// إدارة المتعاونين
export async function addCollaborator(collaboratorData) {
  const { projectId, userId, role, permissions = {} } = collaboratorData
  const db = getDB()

  try {
    const result = await db.query(`
      INSERT INTO project_collaborators (project_id, user_id, role, permissions)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (project_id, user_id) 
      DO UPDATE SET role = $3, permissions = $4
      RETURNING id, project_id, user_id, role, permissions, created_at
    `, [projectId, userId, role, JSON.stringify(permissions)])

    const collaborator = {
      id: result.rows[0].id,
      projectId: result.rows[0].project_id,
      userId: result.rows[0].user_id,
      role: result.rows[0].role,
      permissions: result.rows[0].permissions,
      createdAt: result.rows[0].created_at
    }

    console.log(`✅ تم إضافة متعاون جديد: ${userId} إلى المشروع ${projectId}`)
    return collaborator
  } catch (error) {
    console.error('❌ خطأ في إضافة المتعاون:', error)
    throw new Error('فشل في إضافة المتعاون')
  }
}

export async function removeCollaborator(projectId, userId) {
  const db = getDB()

  try {
    const result = await db.query(
      'DELETE FROM project_collaborators WHERE project_id = $1 AND user_id = $2 RETURNING id',
      [projectId, userId]
    )

    if (result.rows.length === 0) {
      throw new Error('المتعاون غير موجود')
    }

    console.log(`✅ تم إزالة المتعاون: ${userId} من المشروع ${projectId}`)
    return true
  } catch (error) {
    console.error('❌ خطأ في إزالة المتعاون:', error)
    throw new Error(error.message || 'فشل في إزالة المتعاون')
  }
}

export async function updateCollaboratorRole(projectId, userId, newRole) {
  const db = getDB()

  try {
    const result = await db.query(`
      UPDATE project_collaborators 
      SET role = $3
      WHERE project_id = $1 AND user_id = $2
      RETURNING id, project_id, user_id, role, permissions
    `, [projectId, userId, newRole])

    if (result.rows.length === 0) {
      throw new Error('المتعاون غير موجود')
    }

    console.log(`✅ تم تحديث دور المتعاون: ${userId} في المشروع ${projectId} إلى ${newRole}`)
    return result.rows[0]
  } catch (error) {
    console.error('❌ خطأ في تحديث دور المتعاون:', error)
    throw new Error(error.message || 'فشل في تحديث دور المتعاون')
  }
}

export async function getProjectCollaborators(projectId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT pc.id, pc.project_id, pc.user_id, pc.role, pc.permissions, pc.created_at,
             u.username, u.full_name, u.avatar_url
      FROM project_collaborators pc
      JOIN users u ON pc.user_id = u.id
      WHERE pc.project_id = $1
      ORDER BY pc.created_at ASC
    `, [projectId])

    return result.rows.map(row => ({
      id: row.id,
      projectId: row.project_id,
      userId: row.user_id,
      role: row.role,
      permissions: row.permissions,
      createdAt: row.created_at,
      user: {
        id: row.user_id,
        username: row.username,
        fullName: row.full_name,
        avatarUrl: row.avatar_url
      }
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على متعاوني المشروع:', error)
    throw new Error('فشل في الحصول على متعاوني المشروع')
  }
}

// جلسات التعاون
export async function createSession(sessionData) {
  const { projectId, hostId, sessionName, maxParticipants = 10 } = sessionData
  const db = getDB()

  try {
    // إنهاء أي جلسة نشطة سابقة للمشروع
    await db.query(`
      UPDATE collaboration_sessions 
      SET is_active = false, ended_at = CURRENT_TIMESTAMP
      WHERE project_id = $1 AND is_active = true
    `, [projectId])

    // إنشاء جلسة جديدة
    const result = await db.query(`
      INSERT INTO collaboration_sessions (project_id, host_id, session_name, max_participants)
      VALUES ($1, $2, $3, $4)
      RETURNING id, project_id, host_id, session_name, is_active, max_participants, created_at
    `, [projectId, hostId, sessionName, maxParticipants])

    const session = {
      id: result.rows[0].id,
      projectId: result.rows[0].project_id,
      hostId: result.rows[0].host_id,
      sessionName: result.rows[0].session_name,
      isActive: result.rows[0].is_active,
      maxParticipants: result.rows[0].max_participants,
      createdAt: result.rows[0].created_at,
      participants: []
    }

    // حفظ في Redis للوصول السريع
    await cacheUtils.set(`session:${session.id}`, session, 3600)

    console.log(`✅ تم إنشاء جلسة تعاون جديدة: ${session.id} للمشروع ${projectId}`)
    return session
  } catch (error) {
    console.error('❌ خطأ في إنشاء جلسة التعاون:', error)
    throw new Error('فشل في إنشاء جلسة التعاون')
  }
}

export async function joinSession(sessionId, userId) {
  const db = getDB()

  try {
    // التحقق من أن الجلسة نشطة
    const sessionResult = await db.query(
      'SELECT id, max_participants FROM collaboration_sessions WHERE id = $1 AND is_active = true',
      [sessionId]
    )

    if (sessionResult.rows.length === 0) {
      throw new Error('الجلسة غير موجودة أو غير نشطة')
    }

    const maxParticipants = sessionResult.rows[0].max_participants

    // التحقق من عدد المشاركين الحاليين
    const participantsCount = await db.query(
      'SELECT COUNT(*) FROM session_participants WHERE session_id = $1 AND left_at IS NULL',
      [sessionId]
    )

    if (parseInt(participantsCount.rows[0].count) >= maxParticipants) {
      throw new Error('تم الوصول للحد الأقصى من المشاركين')
    }

    // إنهاء أي مشاركة سابقة للمستخدم في نفس الجلسة
    await db.query(`
      UPDATE session_participants 
      SET left_at = CURRENT_TIMESTAMP, is_online = false
      WHERE session_id = $1 AND user_id = $2 AND left_at IS NULL
    `, [sessionId, userId])

    // إضافة المشارك الجديد
    const result = await db.query(`
      INSERT INTO session_participants (session_id, user_id)
      VALUES ($1, $2)
      RETURNING id, session_id, user_id, cursor_position, is_online, joined_at
    `, [sessionId, userId])

    const participant = {
      id: result.rows[0].id,
      sessionId: result.rows[0].session_id,
      userId: result.rows[0].user_id,
      cursorPosition: result.rows[0].cursor_position,
      isOnline: result.rows[0].is_online,
      joinedAt: result.rows[0].joined_at
    }

    console.log(`✅ انضم المستخدم ${userId} إلى الجلسة ${sessionId}`)
    return participant
  } catch (error) {
    console.error('❌ خطأ في الانضمام للجلسة:', error)
    throw new Error(error.message || 'فشل في الانضمام للجلسة')
  }
}

export async function leaveSession(sessionId, userId) {
  const db = getDB()

  try {
    const result = await db.query(`
      UPDATE session_participants 
      SET left_at = CURRENT_TIMESTAMP, is_online = false
      WHERE session_id = $1 AND user_id = $2 AND left_at IS NULL
      RETURNING id
    `, [sessionId, userId])

    if (result.rows.length === 0) {
      throw new Error('المستخدم غير موجود في الجلسة')
    }

    console.log(`✅ غادر المستخدم ${userId} الجلسة ${sessionId}`)
    return true
  } catch (error) {
    console.error('❌ خطأ في مغادرة الجلسة:', error)
    throw new Error(error.message || 'فشل في مغادرة الجلسة')
  }
}

export async function endSession(sessionId) {
  const db = getDB()

  try {
    await db.query('BEGIN')

    // إنهاء الجلسة
    const sessionResult = await db.query(`
      UPDATE collaboration_sessions 
      SET is_active = false, ended_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND is_active = true
      RETURNING id
    `, [sessionId])

    if (sessionResult.rows.length === 0) {
      await db.query('ROLLBACK')
      throw new Error('الجلسة غير موجودة أو منتهية بالفعل')
    }

    // إنهاء مشاركة جميع المستخدمين
    await db.query(`
      UPDATE session_participants 
      SET left_at = CURRENT_TIMESTAMP, is_online = false
      WHERE session_id = $1 AND left_at IS NULL
    `, [sessionId])

    await db.query('COMMIT')

    // حذف من Redis
    await cacheUtils.del(`session:${sessionId}`)

    console.log(`✅ تم إنهاء الجلسة: ${sessionId}`)
    return true
  } catch (error) {
    await db.query('ROLLBACK')
    console.error('❌ خطأ في إنهاء الجلسة:', error)
    throw new Error(error.message || 'فشل في إنهاء الجلسة')
  }
}

export async function getActiveSession(projectId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, project_id, host_id, session_name, is_active, max_participants, created_at
      FROM collaboration_sessions 
      WHERE project_id = $1 AND is_active = true
      ORDER BY created_at DESC
      LIMIT 1
    `, [projectId])

    if (result.rows.length === 0) {
      return null
    }

    const session = {
      id: result.rows[0].id,
      projectId: result.rows[0].project_id,
      hostId: result.rows[0].host_id,
      sessionName: result.rows[0].session_name,
      isActive: result.rows[0].is_active,
      maxParticipants: result.rows[0].max_participants,
      createdAt: result.rows[0].created_at
    }

    return session
  } catch (error) {
    console.error('❌ خطأ في الحصول على الجلسة النشطة:', error)
    throw new Error('فشل في الحصول على الجلسة النشطة')
  }
}

export async function getSessionParticipants(sessionId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT sp.id, sp.session_id, sp.user_id, sp.cursor_position, sp.is_online, sp.joined_at, sp.left_at,
             u.username, u.full_name, u.avatar_url
      FROM session_participants sp
      JOIN users u ON sp.user_id = u.id
      WHERE sp.session_id = $1
      ORDER BY sp.joined_at ASC
    `, [sessionId])

    return result.rows.map(row => ({
      id: row.id,
      sessionId: row.session_id,
      userId: row.user_id,
      cursorPosition: row.cursor_position,
      isOnline: row.is_online,
      joinedAt: row.joined_at,
      leftAt: row.left_at,
      user: {
        id: row.user_id,
        username: row.username,
        fullName: row.full_name,
        avatarUrl: row.avatar_url
      }
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على مشاركي الجلسة:', error)
    throw new Error('فشل في الحصول على مشاركي الجلسة')
  }
}

export async function updateParticipantCursor(sessionId, userId, cursorPosition) {
  const db = getDB()

  try {
    await db.query(`
      UPDATE session_participants 
      SET cursor_position = POINT($3, $4)
      WHERE session_id = $1 AND user_id = $2 AND left_at IS NULL
    `, [sessionId, userId, cursorPosition[0], cursorPosition[1]])

    return true
  } catch (error) {
    console.error('❌ خطأ في تحديث موقع المؤشر:', error)
    return false
  }
}

export async function getUserSessions(userId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT DISTINCT cs.id, cs.project_id, cs.session_name, cs.is_active, cs.created_at,
             p.name as project_name
      FROM collaboration_sessions cs
      JOIN projects p ON cs.project_id = p.id
      LEFT JOIN session_participants sp ON cs.id = sp.session_id
      WHERE cs.host_id = $1 OR sp.user_id = $1
      ORDER BY cs.created_at DESC
      LIMIT 50
    `, [userId])

    return result.rows.map(row => ({
      id: row.id,
      projectId: row.project_id,
      sessionName: row.session_name,
      isActive: row.is_active,
      createdAt: row.created_at,
      projectName: row.project_name
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على جلسات المستخدم:', error)
    throw new Error('فشل في الحصول على جلسات المستخدم')
  }
}

export async function getSessionById(sessionId) {
  const db = getDB()

  try {
    // محاولة الحصول من التخزين المؤقت أولاً
    const cachedSession = await cacheUtils.get(`session:${sessionId}`)
    if (cachedSession) {
      return cachedSession
    }

    const result = await db.query(`
      SELECT id, project_id, host_id, session_name, is_active, max_participants, created_at, ended_at
      FROM collaboration_sessions 
      WHERE id = $1
    `, [sessionId])

    if (result.rows.length === 0) {
      return null
    }

    const session = {
      id: result.rows[0].id,
      projectId: result.rows[0].project_id,
      hostId: result.rows[0].host_id,
      sessionName: result.rows[0].session_name,
      isActive: result.rows[0].is_active,
      maxParticipants: result.rows[0].max_participants,
      createdAt: result.rows[0].created_at,
      endedAt: result.rows[0].ended_at
    }

    // حفظ في التخزين المؤقت إذا كانت الجلسة نشطة
    if (session.isActive) {
      await cacheUtils.set(`session:${sessionId}`, session, 3600)
    }

    return session
  } catch (error) {
    console.error('❌ خطأ في الحصول على الجلسة:', error)
    throw new Error('فشل في الحصول على الجلسة')
  }
}

// إحصائيات التعاون
export async function getCollaborationStats(projectId) {
  const db = getDB()

  try {
    const stats = await db.query(`
      SELECT 
        COUNT(DISTINCT pc.user_id) as total_collaborators,
        COUNT(DISTINCT cs.id) as total_sessions,
        COUNT(DISTINCT sp.user_id) as total_participants
      FROM projects p
      LEFT JOIN project_collaborators pc ON p.id = pc.project_id
      LEFT JOIN collaboration_sessions cs ON p.id = cs.project_id
      LEFT JOIN session_participants sp ON cs.id = sp.session_id
      WHERE p.id = $1
    `, [projectId])

    return {
      totalCollaborators: parseInt(stats.rows[0].total_collaborators) || 0,
      totalSessions: parseInt(stats.rows[0].total_sessions) || 0,
      totalParticipants: parseInt(stats.rows[0].total_participants) || 0
    }
  } catch (error) {
    console.error('❌ خطأ في الحصول على إحصائيات التعاون:', error)
    throw new Error('فشل في الحصول على إحصائيات التعاون')
  }
}
