import { getDB } from '../config/database.js'
import { cacheUtils } from '../config/redis.js'

export async function createProject(projectData) {
  const { name, description, ownerId, isPublic = false, sceneData = {} } = projectData
  const db = getDB()

  try {
    const result = await db.query(`
      INSERT INTO projects (name, description, owner_id, is_public, scene_data)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, name, description, owner_id, is_public, scene_data, created_at, updated_at
    `, [name, description, ownerId, isPublic, JSON.stringify(sceneData)])

    const project = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      description: result.rows[0].description,
      ownerId: result.rows[0].owner_id,
      isPublic: result.rows[0].is_public,
      sceneData: result.rows[0].scene_data,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at
    }

    // حفظ في التخزين المؤقت
    await cacheUtils.set(`project:${project.id}`, project, 1800)

    console.log(`✅ تم إنشاء مشروع جديد: ${name}`)
    return project
  } catch (error) {
    console.error('❌ خطأ في إنشاء المشروع:', error)
    throw new Error(error.message || 'فشل في إنشاء المشروع')
  }
}

export async function getProjectById(projectId) {
  const db = getDB()

  try {
    // محاولة الحصول من التخزين المؤقت أولاً
    const cachedProject = await cacheUtils.get(`project:${projectId}`)
    if (cachedProject) {
      return cachedProject
    }

    const result = await db.query(`
      SELECT id, name, description, owner_id, is_public, thumbnail_url, scene_data, created_at, updated_at
      FROM projects 
      WHERE id = $1
    `, [projectId])

    if (result.rows.length === 0) {
      return null
    }

    const project = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      description: result.rows[0].description,
      ownerId: result.rows[0].owner_id,
      isPublic: result.rows[0].is_public,
      thumbnailUrl: result.rows[0].thumbnail_url,
      sceneData: result.rows[0].scene_data,
      createdAt: result.rows[0].created_at,
      updatedAt: result.rows[0].updated_at
    }

    // حفظ في التخزين المؤقت
    await cacheUtils.set(`project:${projectId}`, project, 1800)

    return project
  } catch (error) {
    console.error('❌ خطأ في الحصول على المشروع:', error)
    throw new Error('فشل في الحصول على المشروع')
  }
}

export async function getAllProjects() {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, name, description, owner_id, is_public, thumbnail_url, created_at, updated_at
      FROM projects 
      ORDER BY updated_at DESC
      LIMIT 100
    `)

    return result.rows.map(project => ({
      id: project.id,
      name: project.name,
      description: project.description,
      ownerId: project.owner_id,
      isPublic: project.is_public,
      thumbnailUrl: project.thumbnail_url,
      createdAt: project.created_at,
      updatedAt: project.updated_at
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على قائمة المشاريع:', error)
    throw new Error('فشل في الحصول على قائمة المشاريع')
  }
}

export async function getUserProjects(userId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT p.id, p.name, p.description, p.owner_id, p.is_public, p.thumbnail_url, p.created_at, p.updated_at
      FROM projects p
      LEFT JOIN project_collaborators pc ON p.id = pc.project_id
      WHERE p.owner_id = $1 OR pc.user_id = $1
      GROUP BY p.id, p.name, p.description, p.owner_id, p.is_public, p.thumbnail_url, p.created_at, p.updated_at
      ORDER BY p.updated_at DESC
    `, [userId])

    return result.rows.map(project => ({
      id: project.id,
      name: project.name,
      description: project.description,
      ownerId: project.owner_id,
      isPublic: project.is_public,
      thumbnailUrl: project.thumbnail_url,
      createdAt: project.created_at,
      updatedAt: project.updated_at
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على مشاريع المستخدم:', error)
    throw new Error('فشل في الحصول على مشاريع المستخدم')
  }
}

export async function getPublicProjects() {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, name, description, owner_id, is_public, thumbnail_url, created_at, updated_at
      FROM projects 
      WHERE is_public = true
      ORDER BY updated_at DESC
      LIMIT 50
    `)

    return result.rows.map(project => ({
      id: project.id,
      name: project.name,
      description: project.description,
      ownerId: project.owner_id,
      isPublic: project.is_public,
      thumbnailUrl: project.thumbnail_url,
      createdAt: project.created_at,
      updatedAt: project.updated_at
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على المشاريع العامة:', error)
    throw new Error('فشل في الحصول على المشاريع العامة')
  }
}

export async function updateProject(projectId, updateData) {
  const db = getDB()

  try {
    const { name, description, isPublic, sceneData, thumbnailUrl } = updateData
    
    const result = await db.query(`
      UPDATE projects 
      SET name = COALESCE($2, name),
          description = COALESCE($3, description),
          is_public = COALESCE($4, is_public),
          scene_data = COALESCE($5, scene_data),
          thumbnail_url = COALESCE($6, thumbnail_url),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING id, name, description, owner_id, is_public, thumbnail_url, scene_data, updated_at
    `, [projectId, name, description, isPublic, 
        sceneData ? JSON.stringify(sceneData) : null, thumbnailUrl])

    if (result.rows.length === 0) {
      throw new Error('المشروع غير موجود')
    }

    const project = {
      id: result.rows[0].id,
      name: result.rows[0].name,
      description: result.rows[0].description,
      ownerId: result.rows[0].owner_id,
      isPublic: result.rows[0].is_public,
      thumbnailUrl: result.rows[0].thumbnail_url,
      sceneData: result.rows[0].scene_data,
      updatedAt: result.rows[0].updated_at
    }

    // تحديث التخزين المؤقت
    await cacheUtils.set(`project:${projectId}`, project, 1800)

    return project
  } catch (error) {
    console.error('❌ خطأ في تحديث المشروع:', error)
    throw new Error(error.message || 'فشل في تحديث المشروع')
  }
}

export async function deleteProject(projectId) {
  const db = getDB()

  try {
    // حذف المشروع وجميع البيانات المرتبطة به
    await db.query('BEGIN')
    
    // حذف سجل التغييرات
    await db.query('DELETE FROM change_history WHERE project_id = $1', [projectId])
    
    // حذف المشاركين في الجلسات
    await db.query(`
      DELETE FROM session_participants 
      WHERE session_id IN (
        SELECT id FROM collaboration_sessions WHERE project_id = $1
      )
    `, [projectId])
    
    // حذف الجلسات
    await db.query('DELETE FROM collaboration_sessions WHERE project_id = $1', [projectId])
    
    // حذف المتعاونين
    await db.query('DELETE FROM project_collaborators WHERE project_id = $1', [projectId])
    
    // حذف المشروع نفسه
    const result = await db.query('DELETE FROM projects WHERE id = $1 RETURNING id', [projectId])
    
    if (result.rows.length === 0) {
      await db.query('ROLLBACK')
      throw new Error('المشروع غير موجود')
    }

    await db.query('COMMIT')

    // حذف من التخزين المؤقت
    await cacheUtils.del(`project:${projectId}`)

    console.log(`✅ تم حذف المشروع: ${projectId}`)
    return true
  } catch (error) {
    await db.query('ROLLBACK')
    console.error('❌ خطأ في حذف المشروع:', error)
    throw new Error(error.message || 'فشل في حذف المشروع')
  }
}

// دوال للتحقق من الصلاحيات
export async function hasAccess(userId, projectId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT p.id 
      FROM projects p
      LEFT JOIN project_collaborators pc ON p.id = pc.project_id
      WHERE p.id = $1 AND (p.is_public = true OR p.owner_id = $2 OR pc.user_id = $2)
    `, [projectId, userId])

    return result.rows.length > 0
  } catch (error) {
    console.error('❌ خطأ في التحقق من صلاحية الوصول:', error)
    return false
  }
}

export async function canEdit(userId, projectId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT p.id 
      FROM projects p
      LEFT JOIN project_collaborators pc ON p.id = pc.project_id
      WHERE p.id = $1 AND (p.owner_id = $2 OR (pc.user_id = $2 AND pc.role IN ('EDITOR', 'ADMIN')))
    `, [projectId, userId])

    return result.rows.length > 0
  } catch (error) {
    console.error('❌ خطأ في التحقق من صلاحية التحرير:', error)
    return false
  }
}

export async function isOwner(userId, projectId) {
  const db = getDB()

  try {
    const result = await db.query(
      'SELECT id FROM projects WHERE id = $1 AND owner_id = $2',
      [projectId, userId]
    )

    return result.rows.length > 0
  } catch (error) {
    console.error('❌ خطأ في التحقق من الملكية:', error)
    return false
  }
}

export async function canManageCollaborators(userId, projectId) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT p.id 
      FROM projects p
      LEFT JOIN project_collaborators pc ON p.id = pc.project_id
      WHERE p.id = $1 AND (p.owner_id = $2 OR (pc.user_id = $2 AND pc.role = 'ADMIN'))
    `, [projectId, userId])

    return result.rows.length > 0
  } catch (error) {
    console.error('❌ خطأ في التحقق من صلاحية إدارة المتعاونين:', error)
    return false
  }
}

// دوال إدارة المشهد
export async function updateScene(projectId, sceneData) {
  return await updateProject(projectId, { sceneData })
}

export async function addObject(projectId, objectData) {
  const project = await getProjectById(projectId)
  if (!project) {
    throw new Error('المشروع غير موجود')
  }

  const sceneData = project.sceneData || { objects: [] }
  sceneData.objects = sceneData.objects || []
  sceneData.objects.push(objectData)

  await updateProject(projectId, { sceneData })
  return true
}

export async function updateObject(projectId, objectId, updates) {
  const project = await getProjectById(projectId)
  if (!project) {
    throw new Error('المشروع غير موجود')
  }

  const sceneData = project.sceneData || { objects: [] }
  sceneData.objects = sceneData.objects || []
  
  const objectIndex = sceneData.objects.findIndex(obj => obj.id === objectId)
  if (objectIndex === -1) {
    throw new Error('الكائن غير موجود')
  }

  sceneData.objects[objectIndex] = { ...sceneData.objects[objectIndex], ...updates }

  await updateProject(projectId, { sceneData })
  return true
}

export async function deleteObject(projectId, objectId) {
  const project = await getProjectById(projectId)
  if (!project) {
    throw new Error('المشروع غير موجود')
  }

  const sceneData = project.sceneData || { objects: [] }
  sceneData.objects = sceneData.objects || []
  sceneData.objects = sceneData.objects.filter(obj => obj.id !== objectId)

  await updateProject(projectId, { sceneData })
  return true
}

export async function getObjectData(projectId, objectId) {
  const project = await getProjectById(projectId)
  if (!project) {
    return null
  }

  const sceneData = project.sceneData || { objects: [] }
  const objects = sceneData.objects || []
  return objects.find(obj => obj.id === objectId) || null
}

// تسجيل التغييرات
export async function logChange(changeData) {
  const { projectId, userId, actionType, objectId, oldData, newData } = changeData
  const db = getDB()

  try {
    await db.query(`
      INSERT INTO change_history (project_id, user_id, action_type, object_id, old_data, new_data)
      VALUES ($1, $2, $3, $4, $5, $6)
    `, [projectId, userId, actionType, objectId, 
        oldData ? JSON.stringify(oldData) : null,
        newData ? JSON.stringify(newData) : null])

    console.log(`📝 تم تسجيل التغيير: ${actionType} في المشروع ${projectId}`)
  } catch (error) {
    console.error('❌ خطأ في تسجيل التغيير:', error)
  }
}

export async function getProjectHistory(projectId, limit = 50, offset = 0) {
  const db = getDB()

  try {
    const result = await db.query(`
      SELECT id, project_id, user_id, action_type, object_id, old_data, new_data, timestamp
      FROM change_history 
      WHERE project_id = $1
      ORDER BY timestamp DESC
      LIMIT $2 OFFSET $3
    `, [projectId, limit, offset])

    return result.rows.map(record => ({
      id: record.id,
      projectId: record.project_id,
      userId: record.user_id,
      actionType: record.action_type,
      objectId: record.object_id,
      oldData: record.old_data,
      newData: record.new_data,
      timestamp: record.timestamp
    }))
  } catch (error) {
    console.error('❌ خطأ في الحصول على تاريخ المشروع:', error)
    throw new Error('فشل في الحصول على تاريخ المشروع')
  }
}
