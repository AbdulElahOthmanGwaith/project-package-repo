#!/bin/bash

# ملف فحص المتطلبات والمساعدة في حل المشاكل
# 3D Web App Requirements Checker

echo "🔍 فحص متطلبات تشغيل تطبيق الويب ثلاثي الأبعاد"
echo "================================================"

# متغيرات للألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# وظائف المساعدة
print_status() {
    if [ $2 -eq 0 ]; then
        echo -e "✅ ${GREEN}$1${NC}"
    else
        echo -e "❌ ${RED}$1${NC}"
    fi
}

print_warning() {
    echo -e "⚠️  ${YELLOW}$1${NC}"
}

print_info() {
    echo -e "ℹ️  $1"
}

# فحص Node.js
echo "📦 فحص Node.js..."
if command -v node >/dev/null 2>&1; then
    NODE_VERSION=$(node --version)
    print_status "Node.js مثبت - النسخة: $NODE_VERSION" 0
    
    # فحص النسخة
    NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1 | sed 's/v//')
    if [ "$NODE_MAJOR" -ge "18" ]; then
        print_status "نسخة Node.js مدعومة" 0
    else
        print_warning "يُنصح بترقية Node.js إلى نسخة 18 أو أحدث"
    fi
else
    print_status "Node.js غير مثبت" 1
    print_info "قم بتثبيت Node.js من: https://nodejs.org/"
fi

# فحص NPM
echo ""
echo "📦 فحص NPM..."
if command -v npm >/dev/null 2>&1; then
    NPM_VERSION=$(npm --version)
    print_status "NPM مثبت - النسخة: $NPM_VERSION" 0
else
    print_status "NPM غير مثبت" 1
fi

# فحص Docker
echo ""
echo "🐳 فحص Docker..."
if command -v docker >/dev/null 2>&1; then
    DOCKER_VERSION=$(docker --version)
    print_status "Docker مثبت - $DOCKER_VERSION" 0
    
    # فحص تشغيل Docker
    if docker info >/dev/null 2>&1; then
        print_status "Docker يعمل بشكل صحيح" 0
    else
        print_warning "Docker مثبت لكنه لا يعمل. جرب: sudo systemctl start docker"
    fi
else
    print_status "Docker غير مثبت" 1
    print_info "تثبيت Docker سيجعل عملية التشغيل أسهل"
fi

# فحص Docker Compose
echo ""
echo "🐳 فحص Docker Compose..."
if command -v docker-compose >/dev/null 2>&1; then
    COMPOSE_VERSION=$(docker-compose --version)
    print_status "Docker Compose مثبت - $COMPOSE_VERSION" 0
elif docker compose version >/dev/null 2>&1; then
    COMPOSE_VERSION=$(docker compose version)
    print_status "Docker Compose (v2) مثبت - $COMPOSE_VERSION" 0
else
    print_status "Docker Compose غير مثبت" 1
fi

# فحص PostgreSQL
echo ""
echo "🐘 فحص PostgreSQL..."
if command -v psql >/dev/null 2>&1; then
    PSQL_VERSION=$(psql --version)
    print_status "PostgreSQL مثبت - $PSQL_VERSION" 0
    
    # فحص الاتصال
    if pg_isready >/dev/null 2>&1; then
        print_status "PostgreSQL يعمل" 0
    else
        print_warning "PostgreSQL مثبت لكنه لا يعمل. جرب: sudo systemctl start postgresql"
    fi
else
    print_status "PostgreSQL غير مثبت" 1
    print_info "مطلوب لتشغيل التطبيق بدون Docker"
fi

# فحص Redis
echo ""
echo "🔴 فحص Redis..."
if command -v redis-cli >/dev/null 2>&1; then
    if redis-cli ping >/dev/null 2>&1; then
        print_status "Redis مثبت ويعمل" 0
    else
        print_warning "Redis مثبت لكنه لا يعمل. جرب: sudo systemctl start redis-server"
    fi
else
    print_status "Redis غير مثبت" 1
    print_info "مطلوب لتشغيل التطبيق بدون Docker"
fi

# فحص المنافذ المطلوبة
echo ""
echo "🌐 فحص المنافذ..."
PORTS=(3000 4000 5432 6379)
OCCUPIED_PORTS=()

for port in "${PORTS[@]}"; do
    if lsof -i ":$port" >/dev/null 2>&1; then
        OCCUPIED_PORTS+=($port)
        print_warning "المنفذ $port مُستخدم"
    else
        print_status "المنفذ $port متاح" 0
    fi
done

# توصيات بناء على النتائج
echo ""
echo "🎯 التوصيات:"
echo "=============="

if command -v docker >/dev/null 2>&1 && (command -v docker-compose >/dev/null 2>&1 || docker compose version >/dev/null 2>&1); then
    echo -e "${GREEN}✅ يمكنك استخدام Docker لتشغيل التطبيق بسهولة!${NC}"
    echo "الأوامر:"
    echo "  cd 3d-web-app"
    echo "  docker-compose up -d"
    echo ""
elif command -v node >/dev/null 2>&1; then
    echo -e "${YELLOW}⚠️  يمكنك تشغيل التطبيق يدوياً${NC}"
    echo "ستحتاج لتثبيت PostgreSQL و Redis أولاً"
    echo ""
else
    echo -e "${RED}❌ تحتاج لتثبيت Node.js أولاً${NC}"
    echo "زر: https://nodejs.org/"
    echo ""
fi

if [ ${#OCCUPIED_PORTS[@]} -gt 0 ]; then
    echo -e "${YELLOW}⚠️  منافذ مُستخدمة: ${OCCUPIED_PORTS[*]}${NC}"
    echo "لإيقاف العمليات على هذه المنافذ:"
    for port in "${OCCUPIED_PORTS[@]}"; do
        echo "  lsof -ti:$port | xargs kill -9"
    done
    echo ""
fi

# خيارات إضافية
echo "🛠  أوامر مفيدة:"
echo "==============="
echo "فحص المنافذ المُستخدمة:"
echo "  netstat -tulpn | grep LISTEN"
echo ""
echo "إيقاف جميع عمليات Node.js:"
echo "  pkill -f node"
echo ""
echo "تنظيف Docker:"
echo "  docker system prune -f"
echo ""

echo "انتهى الفحص! 🎉"